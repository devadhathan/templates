"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"

interface SlideSectionProps {
  heading: string
  backgroundColor: string
  textColor: string
  imagePrompt: string
  delay: number
}

export default function SlideSection({ heading, backgroundColor, textColor, imagePrompt, delay }: SlideSectionProps) {
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    generateImage()
  }, [imagePrompt])

  const generateImage = async () => {
    setIsLoading(true)
    try {
      // Using nano banana API for image generation
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt: imagePrompt }),
      })

      if (!response.ok) {
        throw new Error("Image generation failed")
      }

      const data = await response.json()
      setImageUrl(data.imageUrl)
    } catch (error) {
      console.error("Error generating image:", error)
      // Fallback to placeholder
      setImageUrl(`/placeholder.svg?height=400&width=600&query=${encodeURIComponent(imagePrompt)}`)
    } finally {
      setIsLoading(false)
    }
  }

  const containerVariants = {
    hidden: { opacity: 0, x: -50 },
    visible: {
      opacity: 1,
      x: 0,
      transition: {
        delay,
        duration: 0.8,
        ease: "easeOut",
        staggerChildren: 0.2,
      },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6 },
    },
  }

  return (
    <motion.div
      className="flex-1 p-12 flex flex-col"
      style={{ backgroundColor }}
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      whileHover={{ scale: 1.02 }}
      transition={{ duration: 0.3 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
    >
      <motion.h2 className="mb-8 font-medium text-2xl" style={{ color: textColor }} variants={itemVariants}>
        {heading}
      </motion.h2>

      <motion.div
        className="relative aspect-video mb-8 rounded-lg overflow-hidden shadow-xl cursor-pointer"
        variants={itemVariants}
        whileHover={{ scale: 1.05, rotate: 1 }}
        whileTap={{ scale: 0.98 }}
        onClick={generateImage}
      >
        {isLoading ? (
          <div className="w-full h-full bg-gray-300 animate-pulse flex items-center justify-center">
            <motion.div
              className="w-16 h-16 border-4 border-gray-400 border-t-gray-600 rounded-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
            />
          </div>
        ) : (
          <motion.img
            src={imageUrl || ""}
            alt={imagePrompt}
            className="w-full h-full object-cover"
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
          />
        )}

        <motion.div
          className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 pointer-events-none"
          animate={{ opacity: isHovered ? 1 : 0 }}
          transition={{ duration: 0.3 }}
        >
          <motion.p
            className="text-white font-semibold text-lg"
            initial={{ y: 10 }}
            animate={{ y: isHovered ? 0 : 10 }}
          >
            Click to regenerate
          </motion.p>
        </motion.div>
      </motion.div>

      <motion.p className="font-mono text-sm leading-relaxed mb-4" style={{ color: textColor }} variants={itemVariants}>
        Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
        breakdown of the essential techniques you'll need for comprehensive system cleaning.
      </motion.p>

      <motion.p className="font-mono text-sm leading-relaxed" style={{ color: textColor }} variants={itemVariants}>
        Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
        breakdown of the essential techniques you'll need for comprehensive system cleaning.
      </motion.p>
    </motion.div>
  )
}
