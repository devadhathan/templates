import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Call nano banana API for image generation
    const response = await fetch("https://api.banana.dev/v4/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.BANANA_API_KEY || ""}`,
      },
      body: JSON.stringify({
        prompt,
        num_inference_steps: 30,
        guidance_scale: 7.5,
        width: 768,
        height: 512,
      }),
    })

    if (!response.ok) {
      // Fallback to placeholder if API fails
      const placeholderUrl = `/placeholder.svg?height=512&width=768&query=${encodeURIComponent(prompt)}`
      return NextResponse.json({ imageUrl: placeholderUrl })
    }

    const data = await response.json()

    // Return the generated image URL
    // Adjust this based on nano banana API response structure
    const imageUrl =
      data.output?.image_url ||
      data.imageUrl ||
      `/placeholder.svg?height=512&width=768&query=${encodeURIComponent(prompt)}`

    return NextResponse.json({ imageUrl })
  } catch (error) {
    console.error("[v0] Image generation error:", error)

    // Fallback to placeholder on error
    const { prompt } = await request.json()
    const placeholderUrl = `/placeholder.svg?height=512&width=768&query=${encodeURIComponent(prompt)}`

    return NextResponse.json({ imageUrl: placeholderUrl })
  }
}
