"use client"
import { motion } from "framer-motion"
import SlideSection from "@/components/slide-section"

export default function Page() {
  return (
    <div className="min-h-screen flex items-center justify-center p-8 bg-card py-0">
      <motion.div
        className="w-full max-w-[1920px] flex shadow-2xl overflow-hidden"
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      >
        <SlideSection
          heading="Heading 2"
          backgroundColor="#CBCBCB"
          textColor="#1a1a1a"
          imagePrompt="green mountain landscape with blue sky and white clouds"
          delay={0}
        />
        <SlideSection
          heading="Heading 3"
          backgroundColor="#E8FF02"
          textColor="#1a1a1a"
          imagePrompt="lush green hills with clear blue sky and fluffy clouds"
          delay={0.2}
        />
      </motion.div>
    </div>
  )
}
