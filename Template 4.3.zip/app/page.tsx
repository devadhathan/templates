"use client"

import { useState, useEffect } from "react"

export default function SlidePage() {
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  const generateImage = async () => {
    setIsGenerating(true)
    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt:
            "A professional HVAC technician inspecting an air conditioning system, checking ducts and filters, quality assurance testing equipment, black and white photography style, documentary photo",
        }),
      })

      const data = await response.json()
      if (data.imageUrl) {
        setImageUrl(data.imageUrl)
      }
    } catch (error) {
      console.error("[v0] Error generating image:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  useEffect(() => {
    generateImage()
    setTimeout(() => setIsVisible(true), 100)
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#F2CFD1" }}>
      {/* 16:9 Aspect Ratio Container */}
      <div className="w-full max-w-7xl aspect-video shadow-2xl">
        <div className="w-full h-full flex gap-36 p-16">
          {/* Left Column - Content */}
          <div className="flex-1 flex flex-col justify-center space-y-6 mx-0 mr-20">
            <h1
              className={`font-bold text-[#2D2D2D] leading-tight text-4xl transition-all duration-1000 ease-out ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              The Final Inspection
            </h1>

            <p
              className={`text-lg text-[#5D5D5D] leading-relaxed transition-all duration-1000 ease-out delay-200 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>

            <div className="space-y-4">
              <p
                className={`text-base text-[#4D4D4D] leading-relaxed transition-all duration-1000 ease-out delay-300 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                }`}
              >
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </p>

              <p
                className={`text-base text-[#4D4D4D] leading-relaxed transition-all duration-1000 ease-out delay-500 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                }`}
              >
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </p>

              <p
                className={`text-base text-[#4D4D4D] leading-relaxed transition-all duration-1000 ease-out delay-700 ${
                  isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
                }`}
              >
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </p>
            </div>
          </div>

          {/* Right Column - Generated Images */}
          <div className="w-100 flex flex-col gap-16 justify-center">
            <div
              className={`h-48 bg-gray-200 rounded-lg overflow-hidden shadow-md relative transition-all duration-1000 ease-out delay-400 hover:scale-105 hover:shadow-xl cursor-pointer ${
                isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
              }`}
            >
              {isGenerating && !imageUrl ? (
                <div className="w-full h-full flex items-center justify-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-700"></div>
                </div>
              ) : imageUrl ? (
                <img
                  src={imageUrl || "/placeholder.svg"}
                  alt="HVAC Inspection - AI Generated"
                  className="w-full h-full object-cover grayscale transition-all duration-300 hover:grayscale-0"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <p className="text-gray-500">Loading image...</p>
                </div>
              )}
            </div>

            <div
              className={`h-48 bg-gray-200 rounded-lg overflow-hidden shadow-md relative transition-all duration-1000 ease-out delay-600 hover:scale-105 hover:shadow-xl cursor-pointer ${
                isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-8"
              }`}
            >
              {isGenerating && !imageUrl ? (
                <div className="w-full h-full flex items-center justify-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gray-700"></div>
                </div>
              ) : imageUrl ? (
                <img
                  src={imageUrl || "/placeholder.svg"}
                  alt="HVAC System - AI Generated"
                  className="w-full h-full object-cover grayscale transition-all duration-300 hover:grayscale-0"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <p className="text-gray-500">Loading image...</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
