import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    // Call nano banana API for image generation
    const response = await fetch("https://api.nanobanana.com/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Add API key if required by nano banana
        // 'Authorization': `Bearer ${process.env.NANO_BANANA_API_KEY}`,
      },
      body: JSON.stringify({
        prompt,
        width: 960,
        height: 1080,
        style: "photography",
      }),
    })

    if (!response.ok) {
      throw new Error("Failed to generate image")
    }

    const data = await response.json()

    return NextResponse.json({
      imageUrl: data.image_url || data.url || data.imageUrl,
    })
  } catch (error) {
    console.error("[v0] Error generating image:", error)
    return NextResponse.json({ error: "Failed to generate image" }, { status: 500 })
  }
}
