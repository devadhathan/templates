"use client"

import { useState, useEffect } from "react"
import { Settings } from "lucide-react"

export default function SlidePage() {
  const [imageUrl, setImageUrl] = useState<string>("")
  const [isLoading, setIsLoading] = useState(true)
  const [isCardHovered, setIsCardHovered] = useState(false)

  useEffect(() => {
    // Generate image using nano banana API
    const generateImage = async () => {
      try {
        const response = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt: "black and white landscape photograph of rolling hills with natural vegetation and sky",
          }),
        })

        const data = await response.json()
        if (data.imageUrl) {
          setImageUrl(data.imageUrl)
        } else {
          // Fallback to placeholder
          setImageUrl("/black-and-white-landscape-hills.jpg")
        }
      } catch (error) {
        console.log("[v0] Error generating image:", error)
        // Fallback to placeholder
        setImageUrl("/black-and-white-landscape-hills.jpg")
      } finally {
        setIsLoading(false)
      }
    }

    generateImage()
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#CBCBCB" }}>
      {/* 16:9 Aspect Ratio Container */}
      <div className="relative w-full max-w-7xl aspect-[16/9] overflow-hidden">
        {/* Main Content Grid */}
        <div className="grid grid-cols-2 h-full p-16 animate-in fade-in justify-space between duration-700 py-2 gap-80 px-7">
          {/* Left Column - Text Content */}
          <div className="flex flex-col justify-between animate-in slide-in-from-left-8 duration-700">
            {/* Title Section */}
            <div className="space-y-6">
              <h1 className="font-bold text-black text-4xl">Case study : Topic</h1>

              {/* Subtext with monospace font */}
              <div className="space-y-4 font-mono text-base text-black/80">
                <p>A three-step process for quality assurance and system testing to guarantee peak performance.</p>

                <p>
                  Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                  detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
                </p>
              </div>
            </div>

            {/* Ideas Card with Interactions */}
            <div
              className="relative group cursor-pointer transition-all duration-300 ease-out"
              onMouseEnter={() => setIsCardHovered(true)}
              onMouseLeave={() => setIsCardHovered(false)}
            >
              <div
                className={`relative z-10 p-8 border-black transition-all duration-300 animate-in slide-in-from-bottom-4 animation-delay-300 border ${
                  isCardHovered ? "translate-x-2 translate-y-2 shadow-2xl" : "shadow-lg"
                }`}
                style={{ backgroundColor: "#E8FF02" }}
              >
                <div className="flex items-center gap-3 mb-4">
                  <Settings
                    className={`transition-transform duration-300 w-6 h-6 ${isCardHovered ? "rotate-90" : ""}`}
                  />
                  <h2 className="font-bold text-black text-lg">Ideas</h2>
                </div>

                <p className="text-lg text-black leading-relaxed">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
              </div>

              {/* Card Shadow Effect */}
              <div
                className="absolute inset-0 border-4 border-black transition-all duration-300"
                style={{ backgroundColor: "#1a1a1a" }}
              />
            </div>
          </div>

          {/* Right Column - Image with Blur Effect */}
          <div className="relative w-100 h-full animate-in slide-in-from-right-8 duration-700 animation-delay-150">
            <div className="relative h-full rounded-2xl overflow-hidden">
              {isLoading ? (
                <div className="absolute inset-0 bg-gray-300 animate-pulse" />
              ) : (
                <>
                  {/* Background Blur Layer */}
                  <div
                    className="absolute inset-0 bg-cover bg-center blur-2xl opacity-50 scale-110 transition-all duration-700"
                    style={{ backgroundImage: `url(${imageUrl})` }}
                  />

                  {/* Main Image */}
                  <div
                    className="relative h-full bg-cover bg-center transition-all duration-500 hover:scale-105"
                    style={{ backgroundImage: `url(${imageUrl})` }}
                  />

                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
