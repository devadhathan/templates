"use client"

import { useState, useEffect } from "react"

export default function PresentationSlide() {
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const generateImage = async () => {
    setIsLoading(true)
    setError(null)

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt:
            "A black and white photograph of HVAC system components, air vents, ducts, or mechanical equipment being inspected for quality assurance. Professional, technical, industrial photography style.",
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate image")
      }

      const data = await response.json()
      setImageUrl(data.imageUrl)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    generateImage()
  }, [])

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-8" style={{ backgroundColor: "#C7CAE1" }}>
      {/* 16:9 aspect ratio container */}
      <div className="w-full max-w-[1920px] relative" style={{ aspectRatio: "16/9" }}>
        <div className="absolute inset-0 flex">
          {/* Left side - Image */}
          <div className="w-1/2 relative overflow-hidden">
            {isLoading ? (
              <div className="w-full h-full flex items-center justify-center bg-gray-200">
                <div className="text-center">
                  <div className="inline-block h-12 w-12 animate-spin rounded-full border-4 border-solid border-[#8B8FA8] border-r-transparent mb-4"></div>
                  <p className="text-gray-600 text-lg">Generating contextual image...</p>
                </div>
              </div>
            ) : error ? (
              <div className="w-full h-full flex items-center justify-center bg-gray-200">
                <p className="text-red-600 text-lg">{error}</p>
              </div>
            ) : (
              <img
                src={imageUrl || "/placeholder.svg"}
                alt="HVAC inspection contextual image"
                className="w-full h-full object-cover grayscale"
              />
            )}
          </div>

          {/* Right side - Content */}
          <div className="w-1/2 flex flex-col justify-center px-16 py-12">
            <h1 className="font-bold text-gray-900 mb-8 leading-tight text-5xl">The Final Inspection</h1>

            <p className="text-gray-700 mb-8 leading-relaxed text-base">
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>

            <p className="text-base text-gray-600 leading-relaxed">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you'll need for comprehensive system cleaning.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
