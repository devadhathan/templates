import { NextResponse } from "next/server"
import { GoogleGenerativeAI } from "@google/generative-ai"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    // Initialize Gemini AI
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "")

    // Use Gemini 2.5 Flash Image model for image generation
    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash-image-preview",
    })

    // Generate the image
    const result = await model.generateContent({
      contents: [
        {
          role: "user",
          parts: [{ text: prompt }],
        },
      ],
      generationConfig: {
        responseModalities: ["IMAGE"],
      },
    })

    const response = await result.response

    // Extract image data from response
    if (response.candidates && response.candidates[0]?.content?.parts) {
      const imagePart = response.candidates[0].content.parts.find((part: any) => part.inlineData)

      if (imagePart?.inlineData) {
        const imageData = imagePart.inlineData.data
        const mimeType = imagePart.inlineData.mimeType

        // Convert to data URL
        const imageUrl = `data:${mimeType};base64,${imageData}`

        return NextResponse.json({ imageUrl })
      }
    }

    throw new Error("No image data in response")
  } catch (error) {
    console.error("Error generating image:", error)
    return NextResponse.json({ error: "Failed to generate image" }, { status: 500 })
  }
}
