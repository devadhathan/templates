import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    const apiKey = process.env.nano

    if (!apiKey) {
      return NextResponse.json({ error: "API key not configured" }, { status: 500 })
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `Generate an image of ${prompt}. Make it aesthetic, professional, and visually appealing.`,
                },
              ],
            },
          ],
        }),
      },
    )

    if (!response.ok) {
      const errorData = await response.text()
      console.error("[v0] Image generation error:", errorData)
      return NextResponse.json({ error: "Failed to generate image" }, { status: response.status })
    }

    const data = await response.json()
    console.log("[v0] API Response:", JSON.stringify(data, null, 2))

    const parts = data.candidates?.[0]?.content?.parts
    const imagePart = parts?.find((part: any) => part.inlineData?.mimeType?.startsWith("image/"))

    if (!imagePart?.inlineData?.data) {
      console.error("[v0] No image data in response:", data)
      return NextResponse.json({ error: "No image generated" }, { status: 500 })
    }

    const imageUrl = `data:${imagePart.inlineData.mimeType};base64,${imagePart.inlineData.data}`

    return NextResponse.json({ imageUrl })
  } catch (error) {
    console.error("[v0] Image generation error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
