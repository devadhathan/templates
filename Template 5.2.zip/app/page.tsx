"use client"

import { Slide } from "@/components/slide"

export default function Home() {
  return (
    <div className="flex items-center justify-center bg-neutral-900 p-4">
      <div className="w-full max-w-7xl aspect-video">
        <Slide />
      </div>
    </div>
  )
}
