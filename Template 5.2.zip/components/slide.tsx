"use client"

import { useState, useEffect } from "react"
import { Settings, Zap, TrendingUp, Target, Shield, Award } from "lucide-react"
import { cn } from "@/lib/utils"

const randomIcons = [Settings, Zap, TrendingUp, Target, Shield, Award]

interface SlidePoint {
  id: number
  title: string
  description: string
  icon: typeof Settings
}

export function Slide() {
  const [isVisible, setIsVisible] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(false)

  const [points] = useState<SlidePoint[]>([
    {
      id: 1,
      title: "Heading 1",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
      icon: randomIcons[Math.floor(Math.random() * randomIcons.length)],
    },
    {
      id: 2,
      title: "Heading 2",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
      icon: randomIcons[Math.floor(Math.random() * randomIcons.length)],
    },
    {
      id: 3,
      title: "Heading 3",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
      icon: randomIcons[Math.floor(Math.random() * randomIcons.length)],
    },
  ])

  useEffect(() => {
    // Trigger animations on mount
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    async function generateImage() {
      setIsGenerating(true)
      try {
        const response = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt:
              "Modern minimalist office workspace with organized tools and supplies, soft natural lighting, vibrant yellow and gray color palette, professional photography, clean aesthetic",
          }),
        })

        const data = await response.json()
        if (data.imageUrl) {
          setGeneratedImage(data.imageUrl)
        }
      } catch (error) {
        console.error("Failed to generate image:", error)
      } finally {
        setIsGenerating(false)
      }
    }

    generateImage()
  }, [])

  return (
    <div className="w-full max-w-7xl aspect-video bg-white shadow-2xl overflow-visible">
      <div className="h-full grid grid-cols-2">
        {/* Left Section - Split into two parts */}
        <div className="flex flex-col">
          {/* Top part - Text area with E8FF02 background */}
          <div
            className={cn(
              "flex-1 p-12 flex flex-col justify-center transition-all duration-1000 ease-out py-2.5",
              isVisible ? "opacity-100 translate-x-0 blur-0" : "opacity-0 -translate-x-12 blur-sm",
            )}
            style={{ backgroundColor: "#E8FF02" }}
          >
            <h1
              className="text-4xl font-bold mb-4 text-black leading-tight group-hover:scale-105 transition-transform duration-300"
              style={{ color: "#1a1a1a" }}
            >
              Introduction to the Professional Cleaning Process
            </h1>
            <p className="text-base leading-relaxed font-mono" style={{ color: "#2a2a2a" }}>
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you'll need for comprehensive system cleaning.
            </p>
          </div>

          {/* Bottom part - Image area */}
          <div
            className={cn(
              "flex-1 relative overflow-hidden transition-all duration-1000 delay-200 ease-out bg-gray-200",
              isVisible ? "opacity-100 translate-y-0 blur-0" : "opacity-0 translate-y-12 blur-sm",
            )}
          >
            {isGenerating ? (
              <div className="w-full h-full flex items-center justify-center bg-gray-100">
                <div className="text-center">
                  <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-300 border-t-[#E8FF02] mx-auto mb-4"></div>
                  <p className="text-gray-600 font-mono">Generating image...</p>
                </div>
              </div>
            ) : generatedImage ? (
              <img
                src={generatedImage || "/placeholder.svg"}
                alt="Professional cleaning process visualization"
                className="w-full  object-cover transition-transform duration-500 hover:scale-110"
              />
            ) : (
              <img
                src="/professional-cleaning-equipment-and-tools-aestheti.jpg"
                alt="Professional cleaning process visualization"
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
              />
            )}
          </div>
        </div>

        {/* Right Section - Points with icons */}
        <div className="p-12 flex flex-col gap-10 justify-start" style={{ backgroundColor: "#CBCBCB" }}>
          {points.map((point, index) => {
            const Icon = point.icon
            return (
              <div
                key={point.id}
                className={cn(
                  "group cursor-pointer transition-all duration-700 ease-out",
                  isVisible ? "opacity-100 translate-x-0 blur-0" : "opacity-0 translate-x-12 blur-sm",
                )}
                style={{
                  transitionDelay: `${(index + 1) * 200}ms`,
                }}
              >
                <div className="flex items-start gap-4 hover:translate-x-2 transition-transform duration-300">
                  <div
                    className="p-3 rounded-lg transition-all duration-300 group-hover:scale-110 group-hover:rotate-6"
                    style={{ backgroundColor: "#E8FF02" }}
                  >
                    <Icon className="w-6 h-6" style={{ color: "#1a1a1a" }} />
                  </div>
                  <div className="flex-1">
                    <h3
                      className="text-2xl font-semibold mb-3 transition-colors duration-300 group-hover:opacity-80"
                      style={{ color: "#1a1a1a" }}
                    >
                      {point.title}
                    </h3>
                    <p
                      className="text-sm leading-relaxed font-mono transition-colors duration-300 group-hover:opacity-70"
                      style={{ color: "#2a2a2a" }}
                    >
                      {point.description}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
