"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Settings } from "lucide-react"

export default function SlidePage() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  return (
    <main className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: "#CBCBCB" }}>
      {/* 16:9 Aspect Ratio Container */}
      <div className="w-full max-w-[1920px] aspect-video flex flex-col justify-between p-12 md:p-16 md:py-6">
        {/* Title with fade-in animation */}
        <div className="animate-fade-in-up">
          <h1 className="text-5xl md:text-6xl text-[#2A2A2A] leading-tight max-w-4xl text-pretty lg:text-4xl font-normal">
            Introduction to the Professional Cleaning Process
          </h1>
        </div>

        {/* Cards Container */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 mt-auto">
          {/* Card 1 */}
          <Card
            className="p-8 backdrop-blur-sm border-2 border-[#A0A0A0] hover:border-[#2A2A2A] transition-all duration-300 cursor-pointer animate-fade-in-up bg-[rgba(255,255,255,0)]"
            style={{
              animationDelay: "200ms",
              transform: hoveredCard === 1 ? "translateY(-8px)" : "translateY(0)",
              boxShadow: hoveredCard === 1 ? "0 20px 40px rgba(0,0,0,0.15)" : "0 4px 6px rgba(0,0,0,0.05)",
            }}
            onMouseEnter={() => setHoveredCard(1)}
            onMouseLeave={() => setHoveredCard(null)}
          >
            <Settings
              className="w-10 h-10 mb-4 text-[#2A2A2A] transition-transform duration-300"
              style={{ transform: hoveredCard === 1 ? "rotate(90deg)" : "rotate(0deg)" }}
            />
            <h3 className="text-2xl md:text-3xl font-semibold text-[#2A2A2A] mb-3">Heading 4</h3>
            <p className="text-[#5A5A5A] leading-relaxed font-mono text-base">
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
          </Card>

          {/* Card 2 */}
          <Card
            className="p-8 backdrop-blur-sm border-2 border-[#A0A0A0] hover:border-[#2A2A2A] transition-all duration-300 cursor-pointer animate-fade-in-up bg-[rgba(255,255,255,0)]"
            style={{
              animationDelay: "400ms",
              transform: hoveredCard === 2 ? "translateY(-8px)" : "translateY(0)",
              boxShadow: hoveredCard === 2 ? "0 20px 40px rgba(0,0,0,0.15)" : "0 4px 6px rgba(0,0,0,0.05)",
            }}
            onMouseEnter={() => setHoveredCard(2)}
            onMouseLeave={() => setHoveredCard(null)}
          >
            <Settings
              className="w-10 h-10 mb-4 text-[#2A2A2A] transition-transform duration-300"
              style={{ transform: hoveredCard === 2 ? "rotate(90deg)" : "rotate(0deg)" }}
            />
            <h3 className="text-2xl md:text-3xl font-semibold text-[#2A2A2A] mb-3">Heading 4</h3>
            <p className="text-[#5A5A5A] leading-relaxed font-mono text-base">
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
          </Card>
        </div>
      </div>
    </main>
  )
}
