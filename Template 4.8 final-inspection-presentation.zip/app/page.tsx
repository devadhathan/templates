"use client"

import { Zap, Target, ShieldCheck } from "lucide-react"
import { useEffect, useState } from "react"

export default function Page() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Trigger animation on mount
    setTimeout(() => setIsVisible(true), 100)
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#C7CAE1" }}>
      <div className="w-full max-w-[1920px] aspect-video flex flex-col">
        {/* Header Section */}
        <div className="flex justify-between items-start mb-12">
          <div
            className={`transition-all duration-1000 ${isVisible ? "opacity-100 blur-0 translate-y-0" : "opacity-0 blur-sm -translate-y-4"}`}
          >
            <h1 className="font-bold mb-4 text-4xl" style={{ color: "#2D2D2D" }}>
              The Final Inspection
            </h1>
            <p className="max-w-md text-base" style={{ color: "#4D4D4D" }}>
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
          </div>
          <div
            className={`text-2xl font-medium transition-all duration-1000 delay-200 ${isVisible ? "opacity-100 blur-0 translate-y-0" : "opacity-0 blur-sm -translate-y-4"}`}
            style={{ color: "#2D2D2D" }}
          >
            HAVAC training
          </div>
        </div>

        {/* Cards Section */}
        <div className="grid grid-cols-3 gap-8 flex-1">
          {[0, 1, 2].map((index) => (
            <Card key={index} delay={300 + index * 150} isVisible={isVisible} iconIndex={index} />
          ))}
        </div>
      </div>
    </div>
  )
}

function Card({ delay, isVisible, iconIndex }: { delay: number; isVisible: boolean; iconIndex: number }) {
  const icons = [Zap, Target, ShieldCheck]
  const Icon = icons[iconIndex]

  return (
    <div
      className={`group rounded-3xl p-8 border-2 transition-all duration-700 hover:scale-105 hover:shadow-2xl hover:-translate-y-2 cursor-pointer py-8 my-20 ${
        isVisible ? "opacity-100 blur-0 translate-y-0" : "opacity-0 blur-md translate-y-8"
      }`}
      style={{
        backgroundColor: "rgba(255, 255, 255, 0.3)",
        borderColor: "rgba(90, 90, 90, 0.2)",
        backdropFilter: "blur(10px)",
        transitionDelay: `${delay}ms`,
      }}
    >
      <div>
        <Icon className="w-12 h-12 mb-6" style={{ color: "#2D2D2D" }} />
      </div>
      <h3
        className="font-semibold mb-4 transition-colors duration-300 group-hover:opacity-80 text-xl"
        style={{ color: "#2D2D2D" }}
      >
        Heading 2   
      </h3>
      <p
        className="leading-relaxed transition-colors duration-300 group-hover:opacity-70 text-base"
        style={{ color: "#4D4D4D" }}
      >
        A three-step process for quality assurance and system testing to guarantee peak performance.
      </p>
    </div>
  )
}
