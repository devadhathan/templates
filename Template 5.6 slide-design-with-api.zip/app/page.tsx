"use client"

import { motion } from "framer-motion"
import { Droplets, Wind } from "lucide-react"
import { useState, useEffect } from "react"

export default function PresentationSlide() {
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [isLoadingImage, setIsLoadingImage] = useState(true)

  const cards = [
    {
      icon: Droplets,
      title: "Heading 1",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
    },
    {
      icon: Wind,
      title: "Heading 2",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
    },
  ]

  useEffect(() => {
    const generateImage = async () => {
      try {
        const response = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            prompt:
              "professional HVAC cleaning system with technician working on air ducts, modern industrial setting, clean and bright environment, high quality photo realistic",
          }),
        })

        const data = await response.json()
        if (data.images && data.images.length > 0) {
          const imageData = `data:${data.images[0].mediaType};base64,${data.images[0].base64}`
          setGeneratedImage(imageData)
        }
      } catch (error) {
        console.error("Failed to generate image:", error)
      } finally {
        setIsLoadingImage(false)
      }
    }

    generateImage()
  }, [])

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#CBCBCB] p-8">
      <div className="w-full max-w-[1920px] aspect-video bg-[#CBCBCB] rounded-lg shadow-2xl overflow-hidden">
        <div className="h-full flex flex-col">
          {/* Top Section - 60% */}
          <div className="flex flex items-center justify-between px-16 gap-12 py-4">
            {/* Left Content */}
            <motion.div
              className="flex-1"
              initial={{ opacity: 0, x: -50, filter: "blur(10px)" }}
              animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <motion.h1
                className="font-bold text-gray-900 mb-6 leading-tight text-4xl"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
              >
                Introduction to the Professional Cleaning Process
              </motion.h1>

              <motion.p
                className="text-gray-700 font-mono leading-relaxed text-base"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
              >
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </motion.p>
            </motion.div>

            {/* Right Cards */}
            <div className="flex-1 flex gap-6">
              {cards.map((card, index) => {
                const Icon = card.icon
                return (
                  <motion.div
                    key={index}
                    className="flex-1 backdrop-blur-sm border-2 border-gray-400 p-8 hover:bg-white/80 hover:shadow-xl transition-all duration-300 cursor-pointer bg-[rgba(255,255,255,0)] rounded-none"
                    initial={{ opacity: 0, y: 30, filter: "blur(10px)" }}
                    animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
                    transition={{
                      duration: 0.7,
                      delay: 0.6 + index * 0.2,
                      ease: "easeOut",
                    }}
                    whileHover={{
                      scale: 1.05,
                      transition: { duration: 0.2 },
                    }}
                  >
                    <motion.div initial={{ rotate: 0 }} whileHover={{ rotate: 360 }} transition={{ duration: 0.6 }}>
                      <Icon className="w-6 h-6 text-gray-800 mb-4" strokeWidth={1.5} />
                    </motion.div>
                    <h3 className="font-semibold text-gray-900 mb-4 text-lg">{card.title}</h3>
                    <p className="text-base text-gray-700 font-mono leading-relaxed">{card.description}</p>
                  </motion.div>
                )
              })}
            </div>
          </div>

          {/* Bottom Section - 40% Image */}
          <motion.div
            className="flex-[2] relative overflow-hidden"
            initial={{ opacity: 0, y: 50, filter: "blur(15px)" }}
            animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
            transition={{ duration: 1, delay: 1, ease: "easeOut" }}
          >
            {isLoadingImage ? (
              <div className="w-full h-full flex items-center justify-center bg-gray-300">
                <div className="text-gray-600 text-xl font-mono">Generating contextual image...</div>
              </div>
            ) : generatedImage ? (
              <img
                src={generatedImage || "/placeholder.svg"}
                alt="Professional HVAC Cleaning"
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src="/professional-hvac-cleaning-system.jpg"
                alt="Professional HVAC Cleaning"
                className="w-full h-full object-cover"
              />
            )}

            {/* Overlay gradient for better text visibility if needed */}
            <div className="absolute inset-0 bg-gradient-to-t from-[#CBCBCB]/20 to-transparent pointer-events-none" />
          </motion.div>
        </div>
      </div>
    </div>
  )
}
