export async function POST(req: Request) {
  const { prompt } = await req.json()

  try {
    const response = await fetch("https://image.pollinations.ai/prompt/" + encodeURIComponent(prompt), {
      headers: {
        Authorization: `Bearer ${process.env.nano}`,
      },
    })

    if (!response.ok) {
      throw new Error("Failed to generate image")
    }

    const imageBlob = await response.blob()
    const arrayBuffer = await imageBlob.arrayBuffer()
    const base64 = Buffer.from(arrayBuffer).toString("base64")

    return Response.json({
      images: [
        {
          base64,
          mediaType: imageBlob.type,
        },
      ],
    })
  } catch (error) {
    console.error("Image generation error:", error)
    return Response.json({ error: "Failed to generate image" }, { status: 500 })
  }
}
