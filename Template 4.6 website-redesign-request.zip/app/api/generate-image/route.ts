import { GoogleGenerativeAI } from "@google/generative-ai"
import { NextResponse } from "next/server"

export const runtime = "nodejs"

async function generateBlackWhiteImage(description: string): Promise<string> {
  // For server-side, we'll use a simple approach with Image Placeholder API
  // that's reliable and works consistently
  const seed = Date.now()
  const prompt = encodeURIComponent(description)

  // Using Unsplash API for real industrial photos
  const unsplashUrl = `https://source.unsplash.com/1200x675/?industrial,hvac,machinery,black-white&sig=${seed}`

  return unsplashUrl
}

export async function POST(req: Request) {
  try {
    const { prompt } = await req.json()

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!)
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash-exp" })

    const result = await model.generateContent(
      `Create a concise image search query for: "${prompt}". 
      Focus on: industrial, HVAC systems, machinery, professional equipment, quality assurance.
      Return ONLY 3-5 keywords, no explanations.`,
    )

    const response = await result.response
    const enhancedKeywords = response.text().trim()

    const seed = Date.now()
    const keywords = encodeURIComponent(enhancedKeywords.replace(/\s+/g, ","))
    const imageUrl = `https://source.unsplash.com/1200x675/?${keywords},industrial,black-white&sig=${seed}`

    return NextResponse.json({
      imageUrl,
      description: enhancedKeywords,
    })
  } catch (error: any) {
    console.error("[v0] Image generation error:", error.message || error)

    const seed = Date.now()
    const fallbackUrl = `https://source.unsplash.com/1200x675/?industrial,machinery,hvac&sig=${seed}`

    return NextResponse.json({
      imageUrl: fallbackUrl,
      description: "Industrial HVAC equipment",
    })
  }
}
