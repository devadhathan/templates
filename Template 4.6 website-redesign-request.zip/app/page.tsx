"use client"

import { useEffect, useState } from "react"
import { Settings } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function PresentationSlide() {
  const [imageUrl, setImageUrl] = useState<string>("")
  const [description, setDescription] = useState<string>("")
  const [isLoading, setIsLoading] = useState(true)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    generateImage()
    return () => clearTimeout(timer)
  }, [])

  const generateImage = async () => {
    setIsLoading(true)
    try {
      console.log("[v0] Requesting image generation")
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: "HVAC system inspection, professional quality assurance, industrial setting, high contrast",
        }),
      })

      if (!response.ok) {
        throw new Error(`API responded with status ${response.status}`)
      }

      const data = await response.json()
      console.log("[v0] Image generated successfully")

      if (data.imageBase64) {
        // Use base64 image directly
        setImageUrl(`data:image/jpeg;base64,${data.imageBase64}`)
        setDescription(data.description || "Industrial black and white photography")
      } else {
        throw new Error("No image data received")
      }
    } catch (error) {
      console.error("[v0] Error generating image:", error)
      // Use a reliable placeholder image service as fallback
      const fallbackUrl = "/industrial-hvac-machinery-black-white.jpg"
      setImageUrl(fallbackUrl)
      setDescription("Industrial HVAC inspection photography")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-screen p-8" style={{ backgroundColor: "#C7DFE2" }}>
      {/* 16:9 Container */}
      <div className="w-full max-w-[1600px] aspect-video flex gap-12 p-16">
        {/* Left Section */}
        <div className="flex-1 flex flex-col my-0 justify-start gap-28">
          <div
            className={`transform transition-all duration-1000 ${
              isVisible ? "translate-y-0 opacity-100" : "-translate-y-8 opacity-0"
            }`}
          >
            <h1 className="font-bold text-gray-900 mb-6 text-4xl">The Final Inspection</h1>
            <p className="text-gray-700 mb-8 text-base">
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
            <p className="text-gray-600 leading-relaxed text-base">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you'll need for comprehensive system cleaning.
            </p>
          </div>

          <div
            className={`w-full aspect-video rounded-xl overflow-hidden shadow-xl transform transition-all duration-1000 delay-300 relative ${
              isVisible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
            }`}
          >
            {isLoading ? (
              <div className="w-full h-full bg-gray-300 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-600 border-t-transparent"></div>
              </div>
            ) : (
              <img
                src={imageUrl || "/placeholder.svg?height=675&width=1200"}
                alt="Industrial HVAC inspection black and white photography"
                className="w-full h-full object-cover"
                style={{ filter: "grayscale(100%) contrast(1.3) brightness(0.95)" }}
              />
            )}
          </div>
        </div>

        {/* Right Section - Cards */}
        <div className="flex-1 flex flex-col gap-6 justify-top">
          <Card
            className={`p-8 bg-[#D4F1D4] border-2 border-[#A8E6A8] hover:shadow-2xl hover:scale-105 hover:-translate-y-2 transition-all duration-500 cursor-pointer transform ${
              isVisible ? "translate-x-0 opacity-100" : "translate-x-12 opacity-0"
            }`}
            style={{ transitionDelay: "400ms" }}
          >
            <div className="flex items-start gap-4">
              <Settings className="w-10 text-gray-800 flex-shrink-0 h-8" />
              <div>
                <h2 className="font-bold text-gray-900 mb-4 text-lg">Heading 1</h2>
                <p className="text-gray-700 leading-relaxed text-base">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
              </div>
            </div>
          </Card>

          <Card
            className={`p-8 bg-[#FFE4D6] border-2 border-[#FFCDB2] hover:shadow-2xl hover:scale-105 hover:-translate-y-2 transition-all duration-500 cursor-pointer transform ${
              isVisible ? "translate-x-0 opacity-100" : "translate-x-12 opacity-0"
            }`}
            style={{ transitionDelay: "600ms" }}
          >
            <div className="flex items-start gap-4">
              <Settings className="w-10 text-gray-800 flex-shrink-0 h-8" />
              <div>
                <h2 className="font-bold text-gray-900 mb-4 text-lg">Heading 2</h2>
                <p className="text-gray-700 leading-relaxed text-base">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
