import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    const apiKey = process.env.GEMINI_API_KEY

    if (!apiKey) {
      console.error("[v0] GEMINI_API_KEY not found")
      return NextResponse.json(
        { error: "API key not configured. Please add GEMINI_API_KEY to environment variables." },
        { status: 500 },
      )
    }

    // Using Google Gemini API for image generation
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: `${prompt}. Black and white photography, high contrast, professional quality, monochrome.`,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.9,
            topK: 40,
            topP: 0.95,
          },
        }),
      },
    )

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Gemini API error:", errorText)
      return NextResponse.json({ error: "Failed to generate image" }, { status: response.status })
    }

    const data = await response.json()

    // Extract image from response
    if (data.candidates && data.candidates[0]?.content?.parts) {
      for (const part of data.candidates[0].content.parts) {
        if (part.inlineData) {
          // Convert base64 to data URL
          const imageUrl = `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`
          return NextResponse.json({ imageUrl })
        }
      }
    }

    console.error("[v0] No image data in response:", data)
    return NextResponse.json({ error: "No image generated" }, { status: 500 })
  } catch (error) {
    console.error("[v0] Error in generate-image route:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
