"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"

export default function FinalInspectionSlide() {
  const [leftImage, setLeftImage] = useState<string>("")
  const [rightImage, setRightImage] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
    generateImages()
  }, [])

  const generateImages = async () => {
    setIsGenerating(true)
    // Set fallback images immediately
    setLeftImage("/hvac-inspection-1.jpg")
    setRightImage("/hvac-inspection-2.jpg")

    try {
      // Generate left card image - HVAC system inspection
      const leftResponse = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt:
            "Professional HVAC technician inspecting air conditioning unit with tools, quality control checklist, technical inspection scene, black and white photography, detailed professional setting",
        }),
      })

      const leftData = await leftResponse.json()
      if (leftData.imageUrl) {
        setLeftImage(leftData.imageUrl)
      }

      // Generate right card image - ventilation system close-up
      const rightResponse = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt:
            "Close-up of ventilation ducts and air filters, industrial HVAC components, clean air system, technical details, black and white photography, high contrast",
        }),
      })

      const rightData = await rightResponse.json()
      if (rightData.imageUrl) {
        setRightImage(rightData.imageUrl)
      }
    } catch (error) {
      console.log("[v0] Error generating images, using fallbacks:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#C7DFE2] flex items-center justify-center p-16">
      <div className="w-full max-w-[1600px] aspect-video mx-auto">
        <div className="grid grid-cols-2 gap-12 h-full">
          {/* Left Card */}
          <Card
            className={`backdrop-blur-sm p-12 flex flex-col justify-between transition-all duration-1000 ease-out bg-[rgba(255,255,255,0)] border-primary border-0 shadow-none ${
              isVisible ? "opacity-100 translate-y-0 blur-0" : "opacity-0 translate-y-8 blur-sm"
            } hover:shadow-2xl hover:scale-[1.02] hover:bg-white/95`}
            style={{ transitionDelay: "200ms" }}
          >
            <div>
              <h1 className="font-sans font-bold text-gray-900 mb-6 text-balance text-3xl">The Final Inspection</h1>
              <p className="font-sans text-gray-700 mb-6 leading-relaxed text-pretty text-base">
                A three-step process for quality assurance and system testing to guarantee peak performance.
              </p>
              <p className="font-sans text-gray-600 leading-relaxed text-pretty text-base">
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </p>
            </div>
            <div className="mt-6 rounded-lg overflow-hidden h-48">
              {isGenerating && !leftImage ? (
                <div className="w-full h-full bg-gray-200 animate-pulse flex items-center justify-center">
                  <p className="font-sans text-gray-500">Generating image...</p>
                </div>
              ) : (
                <img
                  src={leftImage || "/placeholder.svg"}
                  alt="HVAC inspection system - black and white"
                  className="w-full object-cover filter grayscale my-0 h-full"
                />
              )}
            </div>
          </Card>

          {/* Right Card */}
          <Card
            className={`backdrop-blur-sm p-12 flex flex-col justify-between transition-all duration-1000 ease-out bg-[rgba(255,255,255,0)] border-foreground border-0 shadow-none ${
              isVisible ? "opacity-100 translate-y-0 blur-0" : "opacity-0 translate-y-8 blur-sm"
            } hover:shadow-2xl hover:scale-[1.02] hover:bg-white/95`}
            style={{ transitionDelay: "400ms" }}
          >
            <div>
              <h1 className="font-sans font-bold text-gray-900 mb-6 text-balance text-3xl">The Final Inspection</h1>
              <p className="font-sans text-gray-700 mb-6 leading-relaxed text-pretty text-base">
                A three-step process for quality assurance and system testing to guarantee peak performance.
              </p>
              <p className="font-sans text-gray-600 leading-relaxed text-pretty text-base">
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </p>
            </div>

            <div className="mt-6 rounded-lg overflow-hidden h-48">
              {isGenerating && !rightImage ? (
                <div className="w-full h-full bg-gray-200 animate-pulse flex items-center justify-center">
                  <p className="font-sans text-gray-500">Generating image...</p>
                </div>
              ) : (
                <img
                  src={rightImage || "/placeholder.svg"}
                  alt="HVAC ventilation system - black and white"
                  className="w-full h-full object-cover filter grayscale"
                />
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
