import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    const apiKey = process.env.GOOGLE_AI_API_KEY

    if (!apiKey) {
      console.error("[v0] GOOGLE_AI_API_KEY not found")
      return NextResponse.json(
        { error: "API key not configured. Please add GOOGLE_AI_API_KEY to your environment variables." },
        { status: 500 },
      )
    }

    // Using Google Gemini API (nano banana) for image generation
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview:generateContent?key=${apiKey}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: prompt,
                },
              ],
            },
          ],
          generationConfig: {
            response_modalities: ["image"],
            media_resolution: "MEDIUM",
          },
        }),
      },
    )

    if (!response.ok) {
      const errorData = await response.text()
      console.error("[v0] Gemini API error:", errorData)
      return NextResponse.json({ error: "Failed to generate image", details: errorData }, { status: response.status })
    }

    const data = await response.json()

    // Extract the image data from the response
    const imagePart = data.candidates?.[0]?.content?.parts?.find((part: any) => part.inline_data)

    if (!imagePart?.inline_data) {
      console.error("[v0] No image data found in response")
      return NextResponse.json({ error: "No image generated" }, { status: 500 })
    }

    // Convert base64 to data URL
    const imageUrl = `data:${imagePart.inline_data.mime_type};base64,${imagePart.inline_data.data}`

    return NextResponse.json({ imageUrl })
  } catch (error) {
    console.error("[v0] Error in generate-image route:", error)
    return NextResponse.json(
      { error: "Internal server error", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
