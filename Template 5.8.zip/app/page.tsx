"use client"

import { useState, useEffect } from "react"

export default function SlidePage() {
  const [heroImage, setHeroImage] = useState<string>("")
  const [card1Image, setCard1Image] = useState<string>("")
  const [card2Image, setCard2Image] = useState<string>("")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted) {
      generateContextualImages()
    }
  }, [mounted])

  const generateContextualImages = async () => {
    // Generate hero image based on slide title
    generateImage(
      "Professional HVAC cleaning equipment and tools, clean workspace, technical environment, photorealistic, high quality",
      setHeroImage,
    )

    // Generate card 1 image - quality assurance theme
    setTimeout(() => {
      generateImage(
        "Quality assurance checklist and testing equipment, professional industrial setting, bright lighting, photorealistic",
        setCard1Image,
      )
    }, 1500)

    // Generate card 2 image - system testing theme
    setTimeout(() => {
      generateImage(
        "Advanced HVAC system testing, digital gauges and monitoring equipment, modern technology, photorealistic",
        setCard2Image,
      )
    }, 3000)
  }

  const generateImage = async (prompt: string, setter: (url: string) => void) => {
    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate image")
      }

      const data = await response.json()
      setter(data.imageUrl)
    } catch (error) {
      console.error("[v0] Error generating image:", error)
    }
  }

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#CBCBCB] flex items-center justify-center">
      <div className="w-full h-full max-w-[1920px] max-h-[1080px] aspect-video p-12 flex gap-8">
        {/* Left Section */}
        <div className="flex-1 flex flex-col justify-between">
          <div
            className={`space-y-6 transition-all duration-1000 ease-out ${
              mounted ? "opacity-100 blur-0 translate-y-0" : "opacity-0 blur-md -translate-y-4"
            }`}
          >
            <h1 className="font-bold text-[#2A2A2A] leading-tight text-4xl">
              Introduction to the Professional Cleaning Process
            </h1>
            <p className="text-[#4A4A4A] leading-relaxed text-base font-mono">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you'll need for comprehensive system cleaning.
            </p>
          </div>

          <div
            className={`transition-all duration-1000 delay-300 ease-out ${
              mounted ? "opacity-100 blur-0 translate-y-0" : "opacity-0 blur-md translate-y-4"
            }`}
          >
            <div className="w-full rounded-xl overflow-hidden shadow-2xl bg-[#E5E5E5] flex items-center justify-center h-96">
              {heroImage ? (
                <img
                  src={heroImage || "/placeholder.svg"}
                  alt="Professional HVAC cleaning equipment"
                  className="w-full h-full object-cover animate-in fade-in zoom-in duration-700"
                />
              ) : (
                <div className="text-[#8A8A8A] text-sm font-medium animate-pulse">Generating contextual image...</div>
              )}
            </div>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex-1 flex flex-col gap-6 justify-start">
          <div
            className={`bg-gradient-to-br from-[#A8E6A3] to-[#88D083] rounded-2xl p-8 shadow-xl transition-all duration-1000 delay-500 ease-out hover:scale-105 hover:shadow-2xl ${
              mounted ? "opacity-100 blur-0 translate-x-0" : "opacity-0 blur-md translate-x-8"
            }`}
          >
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-[#2A2A2A] flex items-center justify-center flex-shrink-0 bg-[rgba(255,255,255,0)]">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path className="text-foreground" strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[#1A1A1A] mb-3">Quality Assurance</h2>
                <p className="text-[#2A2A2A] leading-relaxed font-mono">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
              </div>
            </div>
            {card1Image && (
              <div className="w-full h-32 rounded-lg overflow-hidden shadow-lg">
                <img
                  src={card1Image || "/placeholder.svg"}
                  alt="Quality assurance process"
                  className="w-full h-full object-cover animate-in fade-in duration-700"
                />
              </div>
            )}
          </div>

          <div
            className={`bg-gradient-to-br from-[#FFB8A3] to-[#FF9080] rounded-2xl p-8 shadow-xl transition-all duration-1000 delay-700 ease-out hover:scale-105 hover:shadow-2xl ${
              mounted ? "opacity-100 blur-0 translate-x-0" : "opacity-0 blur-md translate-x-8"
            }`}
          >
            <div className="flex items-start gap-4 mb-4">
              <div className="w-12 h-12 rounded-full bg-[#2A2A2A] flex items-center justify-center flex-shrink-0 text-[rgba(255,255,255,0)] bg-[rgba(255,255,255,0)] border-foreground border-0">
                <svg className="w-6 h-6 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[#1A1A1A] mb-3">System Testing</h2>
                <p className="text-[#2A2A2A] leading-relaxed font-mono">
                  Advanced monitoring and diagnostic procedures ensure optimal system operation and efficiency.
                </p>
              </div>
            </div>
            {card2Image && (
              <div className="w-full h-32 rounded-lg overflow-hidden shadow-lg">
                <img
                  src={card2Image || "/placeholder.svg"}
                  alt="System testing equipment"
                  className="w-full h-full object-cover animate-in fade-in duration-700"
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
