"use client"

import { Settings } from "lucide-react"
import { Card } from "@/components/ui/card"

export default function SlidePage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-[#c5dde0] p-8">
      {/* 16:9 Aspect Ratio Container */}
      <div className="w-full max-w-[1280px] aspect-[16/9] bg-[#c5dde0] p-12 md:p-16 flex flex-col justify-between">
        {/* Header Section with staggered animations */}
        <div className="space-y-6">
          <h1 className="text-5xl md:text-6xl font-light text-[#2c3e50] animate-fade-in animate-delay-100">
            Screen share
          </h1>

          <p className="text-lg md:text-xl text-[#546e7a] max-w-xl animate-fade-in animate-delay-300">
            A three-step process for quality assurance and system testing to guarantee peak performance.
          </p>

          <p className="text-base md:text-lg text-[#546e7a] max-w-2xl leading-relaxed animate-fade-in animate-delay-500">
            Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
            breakdown of the essential techniques you'll need for comprehensive system cleaning.
          </p>
        </div>

        {/* Cards Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl animate-fade-in animate-delay-700">
          <Card className="p-8 bg-[#b8d4d8]/50 border-[#9cb9bd] backdrop-blur-sm hover:bg-[#b8d4d8]/70 hover:scale-105 hover:shadow-xl transition-all duration-300 cursor-pointer group">
            <div className="space-y-4">
              <Settings className="w-10 h-10 text-[#2c3e50] group-hover:rotate-180 transition-transform duration-500" />
              <h2 className="text-2xl font-medium text-[#2c3e50]">Heading 4</h2>
              <p className="text-[#546e7a] leading-relaxed">
                A three-step process for quality assurance and system testing to guarantee peak performance.
              </p>
            </div>
          </Card>

          <Card className="p-8 bg-[#b8d4d8]/50 border-[#9cb9bd] backdrop-blur-sm hover:bg-[#b8d4d8]/70 hover:scale-105 hover:shadow-xl transition-all duration-300 cursor-pointer group">
            <div className="space-y-4">
              <Settings className="w-10 h-10 text-[#2c3e50] group-hover:rotate-180 transition-transform duration-500" />
              <h2 className="text-2xl font-medium text-[#2c3e50]">Heading 4</h2>
              <p className="text-[#546e7a] leading-relaxed">
                A three-step process for quality assurance and system testing to guarantee peak performance.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </main>
  )
}
