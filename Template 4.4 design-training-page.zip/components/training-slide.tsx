"use client"

import { useState, useEffect } from "react"
import { TrainingCard } from "./training-card"

const lessons = [
  {
    id: 1,
    label: "lesson 1",
    heading: "Heading 1",
    prompt:
      "Technical drawing of HVAC heating ventilation system with ducts and pipes, black and white monochrome illustration, high contrast, blueprint style",
  },
  {
    id: 2,
    label: "lesson 2",
    heading: "Heading 2",
    prompt:
      "Technical drawing of air conditioning unit with compressor and cooling coils, black and white monochrome illustration, high contrast, engineering diagram",
  },
  {
    id: 3,
    label: "lesson 3",
    heading: "Heading 3",
    prompt:
      "Technical drawing of digital thermostat control panel with buttons and display, black and white monochrome illustration, high contrast, technical schematic",
  },
  {
    id: 4,
    label: "lesson 4",
    heading: "Heading 4",
    prompt:
      "Technical drawing of industrial ventilation fan with air flow arrows, black and white monochrome illustration, high contrast, mechanical diagram",
  },
]

export function TrainingSlide() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <div className="w-screen h-screen overflow-hidden" style={{ backgroundColor: "#C7DFE2" }}>
      <div className="flex flex-col h-full p-12 lg:p-16 xl:p-20">
        <h1 className="mb-12 text-5xl font-medium text-gray-800 lg:text-4xl">HAVAC training</h1>

        <div className="grid grid-cols-4 gap-8 flex-1 h-24 my-40">
          {lessons.map((lesson, index) => (
            <TrainingCard key={lesson.id} lesson={lesson} index={index} mounted={mounted} />
          ))}
        </div>
      </div>
    </div>
  )
}
