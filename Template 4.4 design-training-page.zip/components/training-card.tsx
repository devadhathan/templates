"use client"

import { useState, useEffect } from "react"
import { cn } from "@/lib/utils"

interface TrainingCardProps {
  lesson: {
    id: number
    label: string
    heading: string
    prompt: string
  }
  index: number
  mounted: boolean
}

export function TrainingCard({ lesson, index, mounted }: TrainingCardProps) {
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    if (mounted) {
      // Stagger image loading for animation effect
      setTimeout(() => {
        setImageUrl(`/placeholder.svg?height=400&width=500&query=${encodeURIComponent(lesson.prompt)}`)
        setIsLoading(false)
      }, index * 200)
    }
  }, [lesson.prompt, mounted, index])

  return (
    <div
      className={cn(
        "group relative bg-white/50 backdrop-blur-sm rounded-lg border border-white/60 p-4 transition-all duration-500 cursor-pointer flex flex-col h-full",
        "hover:bg-white/70 hover:border-white hover:shadow-lg hover:-translate-y-1",
        "opacity-0 translate-y-4",
        mounted && "opacity-100 translate-y-0",
      )}
      style={{
        transitionDelay: `${index * 100}ms`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative mb-3 overflow-hidden rounded-md aspect-video bg-gray-200">
        {isLoading ? (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-8 h-8 border-4 border-gray-300 rounded-full border-t-gray-600 animate-spin" />
          </div>
        ) : imageUrl ? (
          <img
            src={imageUrl || "/placeholder.svg"}
            alt={lesson.heading}
            className={cn(
              "w-full h-full object-cover transition-all duration-500 grayscale contrast-125",
              isHovered && "scale-105",
            )}
          />
        ) : null}
      </div>

      <div className="space-y-1.5">
        <p className="text-sm font-normal text-gray-600">{lesson.label}</p>
        <h2
          className={cn(
            "text-xl font-semibold text-gray-800 transition-colors duration-300",
            isHovered && "text-gray-900",
          )}
        >
          {lesson.heading}
        </h2>
      </div>
    </div>
  )
}
