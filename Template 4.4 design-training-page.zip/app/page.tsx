import { TrainingSlide } from "@/components/training-slide"

export default function Home() {
  return (
    <main className="min-h-screen">
      <TrainingSlide />
    </main>
  )
}
