"use client"

import { useState } from "react"
import Image from "next/image"

export default function EndSlide() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="relative w-full h-screen flex items-center justify-center overflow-hidden"
      style={{ backgroundColor: "#CBCBCB" }}
    >
      {/* 16:9 Container */}
      <div className="relative w-full h-full max-w-[177.78vh] max-h-[56.25vw] flex items-center justify-center">
        {/* Content with blur animation */}
        <div className="flex flex-col items-center gap-8 animate-fade-in-up backdrop-blur-sm">
          {/* Logo */}
          <div className="relative w-32 h-24 animate-fade-in">
            <Image src="/logo.png" alt="Logo" fill className="object-contain" priority />
          </div>
        <div className=" flex flex-col gap-2">
          {/* Main Title */}
          <h1 className="font-bold text-gray-900 animate-fade-in-up animation-delay-200 text-4xl">
            You've made to the end
          </h1>

          {/* Subtitle */}
          <p className="text-gray-600 animate-fade-in-up animation-delay-400 text-base font-mono">
            You can ask more questions or end the lesson
          </p>
          </div>

          {/* Button */}
          <button
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            className="px-12 py-4 rounded-full font-semibold text-black text-lg transition-all duration-300 ease-out animate-fade-in-up animation-delay-600 hover:scale-105 hover:shadow-2xl active:scale-95"
            style={{
              backgroundColor: "#E8FF02",
              transform: isHovered ? "translateY(-2px)" : "translateY(0)",
            }}
          >
            End
          </button>
        </div>
      </div>
    </div>
  )
}
