"use client"

import { useState } from "react"
import { Settings } from "lucide-react"

export default function PresentationSlide() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  return (
    <main className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#CBCBCB" }}>
      <div
        className="w-full max-w-[1200px] aspect-[16/9] grid grid-cols-2 gap-0 overflow-hidden rounded-lg shadow-2xl"
        style={{ backgroundColor: "#CBCBCB" }}
      >
        {/* Left Side - Image */}
        <div className="relative overflow-hidden animate-slide-in-left">
          <img
            src="/professional-hvac-cleaning-technician-with-equipme.jpg"
            alt="Professional Cleaning Process"
            className="w-full h-full object-cover px-4 py-4"
          />
        </div>

        {/* Right Side - Content */}
        <div className="p-12 flex flex-col space-y-6 animate-slide-in-right justify-between">
          {/* Main Title */}
          <h1 className="text-4xl text-gray-900 leading-tight animate-fade-in-up [animation-delay:200ms] font-normal">
            Introduction to the Professional Cleaning Process
          </h1>

          {/* Subtitle - Monospace */}
          <p className="font-mono text-sm text-gray-700 leading-relaxed animate-fade-in-up [animation-delay:400ms]">
            Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
            breakdown of the essential techniques you'll need for comprehensive system cleaning.
          </p>

          {/* Cards */}
          <div className="space-y-4 animate-fade-in-up [animation-delay:600ms]">
            {[1, 2].map((index) => (
              <div
                key={index}
                className="border-2 border-gray-400 rounded-lg p-5 bg-gray-300/50 transition-all duration-300 hover:shadow-lg hover:-translate-y-1 hover:bg-gray-300/80 cursor-pointer"
                onMouseEnter={() => setHoveredCard(index)}
                onMouseLeave={() => setHoveredCard(null)}
              >
                <div className="flex items-start gap-4">
                  <Settings
                    className={`text-gray-800 transition-transform duration-300 ${
                      hoveredCard === index ? "rotate-90 scale-110" : ""
                    }`}
                    size={24}
                  />
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">Quality Process Step {index}</h3>
                    <p className="font-mono text-xs text-gray-700 leading-relaxed">
                      A three-step process for quality assurance and system testing to guarantee peak performance.
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </main>
  )
}
