import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    const apiKey = process.env.nano

    if (apiKey) {
      try {
        const response = await fetch(
          "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "x-goog-api-key": apiKey,
            },
            body: JSON.stringify({
              contents: [
                {
                  parts: [
                    {
                      text: `Generate a professional, high-quality image: ${prompt}`,
                    },
                  ],
                },
              ],
            }),
          },
        )

        if (response.ok) {
          const data = await response.json()

          // Extract base64 image from Gemini response
          if (data.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data) {
            const base64Data = data.candidates[0].content.parts[0].inlineData.data
            return NextResponse.json({
              imageUrl: `data:image/png;base64,${base64Data}`,
            })
          }
        } else {
          console.log("[v0] Gemini API error:", await response.text())
        }
      } catch (geminiError) {
        console.log("[v0] Gemini API error, falling back:", geminiError)
      }
    }

    // Fallback to Pollinations AI (always works)
    const pollinationsUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1920&height=1080&nologo=true&enhance=true`

    return NextResponse.json({
      imageUrl: pollinationsUrl,
    })
  } catch (error) {
    console.error("[v0] Image generation error:", error)

    // Always return a fallback image
    return NextResponse.json({
      imageUrl: `https://image.pollinations.ai/prompt/abstract%20professional%20background?width=1920&height=1080&nologo=true`,
    })
  }
}
