"use client"

import { useState, useEffect } from "react"

export default function PresentationSlide() {
  const [imageLoaded, setImageLoaded] = useState(false)
  const [isHovered, setIsHovered] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string>("")

  const slideData = {
    title: "Introduction to the Professional Cleaning Process",
    description:
      "Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.",
    imageQuery: "professional HVAC technician cleaning air ducts in modern facility, high quality photography",
  }

  useEffect(() => {
    const generateImage = async () => {
      try {
        const response = await fetch("/api/generate-image", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ prompt: slideData.imageQuery }),
        })

        if (response.ok) {
          const data = await response.json()
          setGeneratedImage(data.imageUrl)
        }
      } catch (error) {
        console.error("Failed to generate image:", error)
      }
    }

    generateImage()
  }, [])

  useEffect(() => {
    setImageLoaded(false)
    const timer = setTimeout(() => setImageLoaded(true), 100)
    return () => clearTimeout(timer)
  }, [])

  const currentImageUrl =
    generatedImage ||
    `https://image.pollinations.ai/prompt/${encodeURIComponent(
      slideData.imageQuery,
    )}?width=1920&height=1080&nologo=true&enhance=true`

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-300 via-sky-200 to-sky-100 flex items-center justify-center p-4 md:p-8 rounded-none">
      {/* Animated clouds */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-32 h-16 bg-white/40 rounded-full blur-xl animate-float" />
        <div className="absolute top-40 right-20 w-40 h-20 bg-white/30 rounded-full blur-2xl animate-float-delayed" />
        <div className="absolute bottom-32 left-1/4 w-36 h-18 bg-white/35 rounded-full blur-xl animate-float-slow" />
      </div>

      {/* Main slide container - 16:9 aspect ratio */}
      <div className="relative w-full max-w-7xl aspect-video">
        <div
          className="relative w-full h-full rounded-2xl shadow-2xl overflow-hidden transition-all duration-500"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Background with subtle parallax effect */}
          <div className="absolute inset-0">
            <img
              src={currentImageUrl || "/placeholder.svg"}
              alt="Professional HVAC cleaning background"
              className={`w-full h-full object-cover transition-all duration-700 ${
                imageLoaded ? "opacity-100 scale-100" : "opacity-0 scale-105"
              } ${isHovered ? "scale-110" : "scale-100"}`}
              onLoad={() => setImageLoaded(true)}
            />
            {/* Overlay gradient */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20" />
          </div>

          {/* Content card with blur effect */}
          <div className="absolute inset-0 flex items-end p-8 md:p-16 justify-start flex-row md:px-12 md:py-12 rounded-none">
            <div
              className={`relative w-full max-w-4xl transition-all duration-700 ${
                imageLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <div className="backdrop-blur-md bg-[#E8FF02]/95 p-8 md:p-12 shadow-2xl border border-[#E8FF02] transition-all duration-300 hover:shadow-[0_0_40px_rgba(232,255,2,0.3)] rounded-none">
                <h1 className="text-3xl md:text-5xl font-bold text-black mb-6 animate-fade-in text-balance lg:text-4xl">
                  {slideData.title}
                </h1>
                <p className="text-base text-black/90 leading-relaxed font-mono animate-fade-in-delayed md:text-base">
                  {slideData.description}
                </p>
              </div>

              {/* Decorative accent */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-[#E8FF02] rounded-full blur-2xl opacity-50 animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
