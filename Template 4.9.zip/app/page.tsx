"use client"

import { useState } from "react"
import Image from "next/image"

export default function EndSlide() {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-[#E8C5C5] p-4">
      {/* 16:9 Aspect Ratio Container */}
      <div className="w-full max-w-7xl aspect-[16/9] flex flex-col items-center justify-center relative gap-6">
        {/* Logo with blur-in animation */}
        <div className="animate-[blur-in_0.8s_ease-out] mb-4">
          <Image
            src="/images/design-mode/image.png"
            alt="Logo"
            width={120}
            height={60}
            className="object-contain"
            priority
          />
        </div>

        {/* Heading with staggered blur-in animation */}
        <h1 className="text-5xl md:text-6xl font-bold text-[#1a1a1a] text-center animate-[blur-in_0.8s_ease-out_0.2s_both] lg:text-4xl">
          {"You've made to the end"}
        </h1>

        {/* Subtext with delayed blur-in animation */}
        <p className="text-lg text-[#4a4a4a] text-center max-w-md animate-[blur-in_0.8s_ease-out_0.4s_both] md:text-base">
          You can ask more questions or end the lesson
        </p>

        {/* Button with delayed blur-in and hover interactions */}
        <button
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
          className="mt-4 px-12 py-4 bg-black text-white rounded-full text-lg font-medium 
                     animate-[blur-in_0.8s_ease-out_0.6s_both]
                     transition-all duration-300 ease-out
                     hover:scale-105 hover:shadow-2xl hover:bg-[#1a1a1a]
                     active:scale-95"
        >
          <span className={`inline-block transition-transform duration-300 ${isHovered ? "translate-x-1" : ""}`}>
            End
          </span>
        </button>
      </div>
    </div>
  )
}
