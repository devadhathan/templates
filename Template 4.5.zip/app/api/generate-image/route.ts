import { type NextRequest, NextResponse } from "next/server"
import { GoogleGenerativeAI } from "@google/generative-ai"

export async function POST(request: NextRequest) {
  try {
    const { prompt } = await request.json()

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json({ error: "GEMINI_API_KEY is not configured" }, { status: 500 })
    }

    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY)

    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash-image",
    })

    const result = await model.generateContent(prompt)

    const response = result.response

    const parts = response.candidates?.[0]?.content?.parts

    if (parts) {
      for (const part of parts) {
        if (part.inlineData) {
          const buffer = Buffer.from(part.inlineData.data, "base64")

          return new NextResponse(buffer, {
            headers: {
              "Content-Type": part.inlineData.mimeType || "image/png",
              "Cache-Control": "no-store",
            },
          })
        }
      }
    }

    // Fallback: Return error if no image was generated
    return NextResponse.json({ error: "No image data received from Gemini" }, { status: 500 })
  } catch (error) {
    console.error("[v0] Error generating image:", error)
    return NextResponse.json({ error: "Failed to generate image", details: String(error) }, { status: 500 })
  }
}
