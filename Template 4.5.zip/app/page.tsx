"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Settings } from "lucide-react"

export default function PresentationSlide() {
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    // Generate image spontaneously on mount
    generateImage()
  }, [])

  const generateImage = async () => {
    setIsLoading(true)
    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt:
            "A black and white minimalist photograph of quality assurance inspection, industrial testing equipment, system diagnostics, professional technical workspace, monochrome, high contrast",
        }),
      })

      if (response.ok) {
        const blob = await response.blob()
        const imageUrl = URL.createObjectURL(blob)
        setGeneratedImage(imageUrl)
      }
    } catch (error) {
      console.error("[v0] Error generating image:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#DBE1C7] p-8">
      {/* 16:9 Container */}
      <div className="w-full max-w-[1600px] aspect-video bg-[#DBE1C7] flex flex-col">
        {/* Upper Section with Text and Cards */}
        <div className="flex-1 grid grid-cols-2 gap-12 p-16 py-6">
          {/* Left Side - Title and Description */}
          <div className="flex flex-col justify-top space-y-6">
            <h1
              className={`font-bold text-[#2C2C2C] text-3xl ${mounted ? "animate-fade-in-up" : "opacity-0"}`}
              style={{ animationDelay: "0.1s" }}
            >
              The Final Inspection
            </h1>
            <p
              className={`text-xl text-[#4A4A4A] leading-relaxed ${mounted ? "animate-fade-in-up" : "opacity-0"}`}
              style={{ animationDelay: "0.3s" }}
            >
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
          </div>

          {/* Right Side - Cards */}
          <div className="flex flex-row gap-6 justify-top">
            <Card
              className={`bg-[#C8BAAC] border-[#9B8B7E] hover:bg-[#BFB0A1] transition-all duration-300 hover:scale-105 hover:shadow-xl cursor-pointer py-0 my-12 bg-[rgba(255,255,255,0)] text-foreground ${mounted ? "animate-fade-in-up" : "opacity-0"}`}
              style={{ animationDelay: "0.5s" }}
            >
              <CardContent className="p-8">
                <Settings className="w-10 mb-4 text-[#2C2C2C] h-8" />
                <h2 className="font-bold mb-3 text-[#2C2C2C] text-lg">Heading 1</h2>
                <p className="text-[#4A4A4A] leading-relaxed">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
              </CardContent>
            </Card>

            <Card
              className={`bg-[#C8BAAC] border-[#9B8B7E] hover:bg-[#BFB0A1] transition-all duration-300 hover:scale-105 hover:shadow-xl cursor-pointer py-8 my-11 px-3 bg-[rgba(255,255,255,0)] ${mounted ? "animate-fade-in-up" : "opacity-0"}`}
              style={{ animationDelay: "0.7s" }}
            >
              <CardContent className="p-8">
                <Settings className="w-10 mb-4 text-[#2C2C2C] h-8" />
                <h2 className="font-bold mb-3 text-[#2C2C2C] text-lg">Heading 2</h2>
                <p className="text-[#4A4A4A] leading-relaxed">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Lower Section - Generated Image */}
        <div
          className={`h-[40%] relative overflow-hidden ${mounted ? "animate-fade-in" : "opacity-0"}`}
          style={{ animationDelay: "0.9s" }}
        >
          {isLoading ? (
            <div className="w-full h-full bg-[#A8A8A8] flex items-center justify-center">
              <div className="text-[#4A4A4A] text-lg">Generating contextual image...</div>
            </div>
          ) : generatedImage ? (
            <img
              src={generatedImage || "/placeholder.svg"}
              alt="Quality inspection workspace"
              className="w-full h-full object-cover grayscale"
            />
          ) : (
            <div className="w-full h-full bg-[#A8A8A8] flex items-center justify-center">
              <div className="text-[#4A4A4A] text-lg">Image generation in progress...</div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
