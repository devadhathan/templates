"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

export default function SlidePage() {
  const [isHovered, setIsHovered] = useState(false)
  const [imageLoaded, setImageLoaded] = useState(false)

  // Placeholder for nano banana API integration
  const generateContextualImage = async (prompt: string) => {
    // TODO: Integrate nano banana API here
    console.log("Generating image for:", prompt)
    // return await nanoBananaAPI.generate(prompt)
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-4 md:p-8">
      {/* 16:9 Slide Container */}
      <div
        className="relative w-full max-w-7xl aspect-[16/9] overflow-hidden rounded-lg shadow-2xl transition-all duration-500"
        style={{ backgroundColor: "#F2CFD1" }}
      >
        {/* Content Grid */}
        <div className="absolute inset-0 grid grid-cols-1 md:grid-cols-2 gap-8 p-8 md:p-12 lg:p-16">
          {/* Left Content */}
          <div className="flex flex-col justify-center space-y-6 animate-fade-in-up">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 animate-fade-in-up">
              {"Welcome to simulation"}
            </h1>

            <p className="text-lg md:text-xl text-gray-700 font-medium animate-fade-in-up animation-delay-200">
              {"A three-step process for quality assurance and system testing to guarantee peak performance."}
            </p>

            <p className="text-base md:text-lg text-gray-600 leading-relaxed animate-fade-in-up animation-delay-400">
              {
                "Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed breakdown of the essential techniques you'll need for comprehensive system cleaning."
              }
            </p>
          </div>

          {/* Right Image with Interactive Effects */}
          <div
            className="flex items-center justify-center animate-fade-in-up animation-delay-600"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <div
              className={`relative w-full h-full max-h-96 rounded-lg overflow-hidden shadow-xl transition-all duration-700 ${
                isHovered ? "scale-105 shadow-2xl" : "scale-100"
              }`}
            >
              {/* Image with subtle blur animation */}
              <img
                src="/images/image.png"
                alt="Mountain landscape"
                className={`w-full h-full object-cover transition-all duration-700 ${
                  isHovered ? "blur-[2px] brightness-110" : "blur-0"
                }`}
                onLoad={() => setImageLoaded(true)}
              />

              {/* Overlay on hover */}
              <div
                className={`absolute inset-0 bg-gradient-to-t from-black/30 to-transparent transition-opacity duration-500 ${
                  isHovered ? "opacity-100" : "opacity-0"
                }`}
              />

              {/* Loading state */}
              {!imageLoaded && <div className="absolute inset-0 bg-gray-200 animate-pulse" />}
            </div>
          </div>
        </div>

        {/* Next Button */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-fade-in-up animation-delay-800">
          <Button
            size="lg"
            className="bg-black hover:bg-gray-800 text-white px-12 py-6 text-lg font-semibold rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-xl active:scale-95"
            onClick={() => {
              console.log("[v0] Next button clicked")
              // TODO: Add navigation logic
            }}
          >
            Next
          </Button>
        </div>

        {/* Nano Banana API Integration Note */}
        <div className="absolute top-4 right-4 opacity-0 hover:opacity-100 transition-opacity duration-300">
          <div className="bg-white/80 backdrop-blur-sm rounded-lg p-2 text-xs text-gray-600">
            {"Ready for nano banana API"}
          </div>
        </div>
      </div>
    </main>
  )
}
