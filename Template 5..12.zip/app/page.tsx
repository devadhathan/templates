"use client"

import { useState, useEffect } from "react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Settings } from "lucide-react"

export default function SlidePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    setIsVisible(true)
    generateImage()
  }, [])

  const generateImage = async () => {
    setIsLoading(true)
    try {
      // Using placeholder for now - replace with your nano banana API endpoint
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: "Professional HVAC system in a modern building, clean environment, technical photography",
        }),
      })

      if (response.ok) {
        const data = await response.json()
        setImageUrl(data.imageUrl)
      } else {
        // Fallback to placeholder
        setImageUrl("/professional-hvac-cleaning-equipment.jpg")
      }
    } catch (error) {
      console.error("[v0] Image generation failed:", error)
      setImageUrl("/professional-hvac-cleaning-equipment.jpg")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#CBCBCB" }}>
      <div className="w-full max-w-[1280px] max-h-[1280px]  grid md:grid-cols-2 gap-0 overflow-hidden rounded-lg shadow-2xl">
        {/* Left Side - Gray Background */}
        <div
          className={`p-12 flex flex-col transition-all duration-1000 justify-start gap-10 ${
            isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"
          }`}
          style={{ backgroundColor: "#CBCBCB" }}
        >
          <div>
            <h1 className="text-4xl mb-6 text-gray-900 md:text-4xl font-medium">
              Introduction to the Professional Cleaning Process
            </h1>
            <p className="font-mono text-sm md:text-base text-gray-700 leading-relaxed">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you&apos;ll need for comprehensive system cleaning.
            </p>
          </div>

          <Card
            className={`p-6 border-2 border-gray-400 hover:border-gray-600 transition-all duration-300 cursor-pointer bg-[rgba(255,255,255,0)] text-foreground ${
              isVisible ? "opacity-100 translate-y-0 delay-300" : "opacity-0 translate-y-8"
            }`}
            style={{ backgroundColor: "#E0E0E0" }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={() => alert("Quality Assurance Process Details")}
          >
            <Settings className={`w-8 h-8 mb-4 transition-transform duration-300 ${isHovered ? "rotate-90" : ""}`} />
            <h2 className="text-2xl font-bold mb-3 text-gray-900">Heading 4</h2>
            <p className="font-mono text-sm text-gray-700">
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
          </Card>
        </div>

        {/* Right Side - Lime Card */}
        <div
          className={`p-12 flex flex-col transition-all duration-1000 delay-200 ${
            isVisible ? "opacity-100 translate-x-0" : "opacity-0 translate-x-12"
          }`}
          style={{ backgroundColor: "#E8FF02" }}
        >
          <h2 className="mb-6 text-gray-900 font-normal text-2xl">Heading 3</h2>

          <div
            className={`relative mb-6 rounded-lg overflow-hidden shadow-lg transition-all duration-700 delay-500 ${
              isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
            }`}
          >
            {isLoading ? (
              <div className="aspect-[3/2] bg-blue-200 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-4 border-gray-900 border-t-transparent"></div>
              </div>
            ) : (
              <img
                src={imageUrl || "/placeholder.svg?height=400&width=600&query=professional+hvac+system"}
                alt="Professional HVAC System"
                className="w-full aspect-[3/2] object-cover hover:scale-105 transition-transform duration-500"
              />
            )}
            <Button
              onClick={generateImage}
              className="absolute bottom-4 right-4 bg-gray-900 hover:bg-gray-700 text-white"
              size="sm"
            >
              Regenerate
            </Button>
          </div>

          <div className="space-y-4">
            <p className="font-mono text-sm md:text-base text-gray-900 leading-relaxed">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you&apos;ll need for comprehensive system cleaning.
            </p>

            <p className="font-mono text-sm md:text-base text-gray-900 leading-relaxed">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you&apos;ll need for comprehensive system cleaning.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
