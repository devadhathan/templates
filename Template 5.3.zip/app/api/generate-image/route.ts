import { NextResponse } from "next/server"

export async function POST() {
  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.nano || "",
        },
        body: JSON.stringify({
          instances: [
            {
              prompt:
                "A professional photograph of beautiful scenic landscape with lush green rolling hills, blue sky with white clouds, natural lighting, high quality, cinematic, 16:9 aspect ratio",
            },
          ],
          parameters: {
            sampleCount: 1,
            aspectRatio: "16:9",
          },
        }),
      },
    )

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Imagen API error:", errorText)
      // Fallback to placeholder
      return NextResponse.json({
        imageUrl: "/beautiful-scenic-landscape-with-lush-green-rolling.jpg",
      })
    }

    const result = await response.json()
    const imageBase64 = result.predictions?.[0]?.bytesBase64Encoded

    const imageUrl = imageBase64
      ? `data:image/png;base64,${imageBase64}`
      : "/beautiful-scenic-landscape-with-lush-green-rolling.jpg"

    return NextResponse.json({ imageUrl })
  } catch (error) {
    console.error("[v0] Image generation error:", error)
    // Fallback to placeholder on error
    return NextResponse.json({
      imageUrl: "/beautiful-scenic-landscape-with-lush-green-rolling.jpg",
    })
  }
}
