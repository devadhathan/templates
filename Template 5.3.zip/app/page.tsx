"use client"

import { useEffect, useState } from "react"

export default function Page() {
  const [imageUrl, setImageUrl] = useState<string>("")
  const [loading, setLoading] = useState(true)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    async function generateImage() {
      try {
        const response = await fetch("/api/generate-image", {
          method: "POST",
        })
        const data = await response.json()
        if (data.imageUrl) {
          setImageUrl(data.imageUrl)
        }
      } catch (error) {
        console.error("Error generating image:", error)
        setImageUrl("/beautiful-scenic-landscape-with-lush-green-rolling.jpg")
      } finally {
        setLoading(false)
        setTimeout(() => setIsVisible(true), 100)
      }
    }

    generateImage()
  }, [])

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-950 p-4">
      <div
        className={`w-full max-w-7xl overflow-hidden rounded-lg shadow-2xl transition-all duration-1000 ${
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
        }`}
        style={{ aspectRatio: "16/9" }}
      >
        <div className="grid h-full grid-cols-2">
          {/* Left section with text */}
          <div
            className={`flex flex-col p-12 transition-all duration-700 delay-200 justify-start ${
              isVisible ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-8"
            }`}
            style={{ backgroundColor: "#CBCBCB" }}
          >
            <h1 className="mb-6 font-bold leading-tight text-gray-900 text-4xl">
              Introduction to the Professional Cleaning Process
            </h1>
            <p className="font-mono text-base leading-relaxed text-gray-800">
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you&apos;ll need for comprehensive system cleaning.
            </p>
          </div>

          {/* Right section with generated image */}
          <div className="relative overflow-hidden p-6" style={{ backgroundColor: "#CBCBCB" }}>
            {loading ? (
              <div className="flex h-full items-center justify-center">
                <div className="h-12 w-12 animate-spin rounded-full border-4 border-gray-300 border-t-gray-600" />
              </div>
            ) : (
              <div
                className={`h-full rounded-lg overflow-hidden transition-all duration-1000 delay-500 ${
                  isVisible ? "opacity-100 blur-0 scale-100" : "opacity-0 blur-md scale-105"
                }`}
              >
                <img
                  src={imageUrl || "/placeholder.svg"}
                  alt="Scenic landscape with green hills and blue sky"
                  className="h-full w-full object-cover transition-transform duration-700 hover:scale-105 rounded-none"
                />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
