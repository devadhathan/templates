"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence, type PanInfo } from "framer-motion"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { generateImageUrl } from "./actions"

const slides = [
  {
    id: 1,
    title: "Quality Assurance",
    description:
      "A comprehensive inspection process to verify all systems meet industry standards and operational requirements.",
    color: "#C7CAE1",
  },
  {
    id: 2,
    title: "System Testing",
    description:
      "If any areas require more attention, they must be immediately addressed to ensure a complete and thorough cleaning.",
    color: "#E1C7E0",
  },
  {
    id: 3,
    title: "Performance Verification",
    description: "Final verification ensures peak system performance and optimal efficiency for long-term reliability.",
    color: "#C7DFE2",
  },
]

export default function PresentationSlide() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [direction, setDirection] = useState(0)
  const [imageUrls, setImageUrls] = useState<Record<number, string>>({})
  const [loadingImages, setLoadingImages] = useState<Record<number, boolean>>({})

  useEffect(() => {
    const generateImages = async () => {
      for (const slide of slides) {
        setLoadingImages((prev) => ({ ...prev, [slide.id]: true }))

        try {
          // Generate image URL using contextual prompt
          const imageUrl = await generateImageUrl(slide.title, slide.description)
          setImageUrls((prev) => ({ ...prev, [slide.id]: imageUrl }))
        } catch (error) {
          console.error(`Error generating image for slide ${slide.id}:`, error)
          // Fallback to placeholder
          setImageUrls((prev) => ({
            ...prev,
            [slide.id]: `/placeholder.svg?height=600&width=800&query=${encodeURIComponent(slide.title)}`,
          }))
        } finally {
          setLoadingImages((prev) => ({ ...prev, [slide.id]: false }))
        }
      }
    }

    generateImages()
  }, [])

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 300 : -300,
      opacity: 0,
      scale: 0.9,
    }),
    center: {
      x: 0,
      opacity: 1,
      scale: 1,
    },
    exit: (direction: number) => ({
      x: direction > 0 ? -300 : 300,
      opacity: 0,
      scale: 0.9,
    }),
  }

  const handleDragEnd = (event: MouseEvent | TouchEvent | PointerEvent, info: PanInfo) => {
    const swipeThreshold = 50
    if (info.offset.x < -swipeThreshold && currentIndex < slides.length - 1) {
      paginate(1)
    } else if (info.offset.x > swipeThreshold && currentIndex > 0) {
      paginate(-1)
    }
  }

  const paginate = (newDirection: number) => {
    setDirection(newDirection)
    setCurrentIndex((prevIndex) => {
      const nextIndex = prevIndex + newDirection
      if (nextIndex < 0) return 0
      if (nextIndex >= slides.length) return slides.length - 1
      return nextIndex
    })
  }

  return (
    <div
      className="relative w-full h-screen overflow-hidden flex items-center justify-center"
      style={{ backgroundColor: "#DBE1C7", aspectRatio: "16/9" }}
    >
      {/* Left Content Section */}
      <motion.div
        className="absolute left-8 md:left-16 top-1/2 -translate-y-1/2 max-w-xl z-10"
        initial={{ opacity: 0, x: -50 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <motion.h1
          className="text-5xl md:text-6xl font-bold mb-6 text-[#2C3E2F] lg:text-5xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          The Final Inspection
        </motion.h1>
        <motion.p
          className="text-lg md:text-xl text-[#4A5D4F] mb-4 leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          A three-step process for quality assurance and system testing to guarantee peak performance.
        </motion.p>
        <motion.p
          className="text-base md:text-lg text-[#5A6D5F] leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
          breakdown of the essential techniques you'll need for comprehensive system cleaning.
        </motion.p>
      </motion.div>

      {/* Cards Stack Section */}
      <div
        className="absolute right-8 md:right-24 top-1/2 -translate-y-1/2 w-[400px] h-[600px]"
        style={{ perspective: "2000px" }}
      >
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={currentIndex}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: "spring", stiffness: 300, damping: 30 },
              opacity: { duration: 0.3 },
              scale: { duration: 0.3 },
            }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.2}
            onDragEnd={handleDragEnd}
            className="absolute inset-0 cursor-grab active:cursor-grabbing"
            style={{
              transformStyle: "preserve-3d",
              zIndex: 10,
            }}
          >
            <motion.div
              className="w-full h-full rounded-3xl shadow-2xl overflow-hidden"
              style={{ backgroundColor: slides[currentIndex].color }}
              whileHover={{ scale: 1.02, boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.3)" }}
              transition={{ duration: 0.2 }}
            >
              {/* Image Container */}
              <div className="relative w-full h-[60%] overflow-hidden bg-gradient-to-br from-gray-100 to-gray-200">
                {loadingImages[slides[currentIndex].id] ? (
                  <div className="w-full h-full flex items-center justify-center">
                    <motion.div
                      className="w-12 h-12 border-4 border-[#4A5D4F]/20 border-t-[#4A5D4F] rounded-full"
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
                    />
                  </div>
                ) : (
                  <motion.img
                    src={
                      imageUrls[slides[currentIndex].id] ||
                      `/placeholder.svg?height=600&width=800&query=${encodeURIComponent(slides[currentIndex].title)}`
                    }
                    alt={slides[currentIndex].title}
                    className="w-full h-full object-cover grayscale"
                    initial={{ scale: 1.2, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.6, ease: "easeOut" }}
                  />
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent" />
              </div>

              {/* Content Container */}
              <div className="p-8 h-[40%] flex flex-col justify-between">
                <div>
                  <motion.h2
                    className="text-3xl font-bold mb-3 text-[#2C3E2F]"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.2 }}
                  >
                    {slides[currentIndex].title}
                  </motion.h2>
                  <motion.p
                    className="text-[#4A5D4F] leading-relaxed text-balance"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.3 }}
                  >
                    {slides[currentIndex].description}
                  </motion.p>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </AnimatePresence>

        {/* Background Cards (Stack Effect) */}
        {currentIndex < slides.length - 1 && (
          <>
            <motion.div
              className="absolute inset-0 rounded-3xl shadow-xl pointer-events-none"
              style={{
                backgroundColor: slides[currentIndex + 1]?.color,
                transformStyle: "preserve-3d",
                zIndex: 9,
              }}
              initial={{ opacity: 0, scale: 0.95, y: 20, rotateZ: 0 }}
              animate={{ opacity: 0.7, scale: 0.95, y: 20, rotateZ: 3 }}
              transition={{ duration: 0.3 }}
            />
            {currentIndex < slides.length - 2 && (
              <motion.div
                className="absolute inset-0 rounded-3xl shadow-lg pointer-events-none"
                style={{
                  backgroundColor: slides[currentIndex + 2]?.color,
                  transformStyle: "preserve-3d",
                  zIndex: 8,
                }}
                initial={{ opacity: 0, scale: 0.9, y: 40, rotateZ: 0 }}
                animate={{ opacity: 0.4, scale: 0.9, y: 40, rotateZ: -3 }}
                transition={{ duration: 0.3 }}
              />
            )}
          </>
        )}
      </div>

      {/* Navigation Controls */}
      <div className="absolute bottom-8 right-8 md:right-24 flex items-center gap-4 z-20">
        <Button
          variant="outline"
          size="icon"
          onClick={() => paginate(-1)}
          disabled={currentIndex === 0}
          className="rounded-full bg-white/90 hover:bg-white disabled:opacity-30 border-[#4A5D4F]/20"
        >
          <ChevronLeft className="w-5 h-5 text-[#2C3E2F]" />
        </Button>

        <div className="flex gap-2">
          {slides.map((_, index) => (
            <motion.button
              key={index}
              onClick={() => {
                setDirection(index > currentIndex ? 1 : -1)
                setCurrentIndex(index)
              }}
              className="relative"
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }}
            >
              <div
                className={`w-2.5 h-2.5 rounded-full transition-all duration-300 ${
                  index === currentIndex ? "bg-[#2C3E2F] w-8" : "bg-[#4A5D4F]/40 hover:bg-[#4A5D4F]/60"
                }`}
              />
            </motion.button>
          ))}
        </div>

        <Button
          variant="outline"
          size="icon"
          onClick={() => paginate(1)}
          disabled={currentIndex === slides.length - 1}
          className="rounded-full bg-white/90 hover:bg-white disabled:opacity-30 border-[#4A5D4F]/20"
        >
          <ChevronRight className="w-5 h-5 text-[#2C3E2F]" />
        </Button>
      </div>

      {/* Swipe Hint */}
      {currentIndex === 0 && (
        <motion.div
          className="absolute bottom-24 right-8 md:right-24 text-[#4A5D4F] text-sm"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.5 }}
        >
          <motion.div
            animate={{ x: [0, -8, 0] }}
            transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, repeatDelay: 0.5 }}
          >
            ← Swipe or drag to navigate →
          </motion.div>
        </motion.div>
      )}
    </div>
  )
}
