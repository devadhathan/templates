"use server"

import { generateText } from "ai"

export async function generateImagePrompt(cardTitle: string, cardDescription: string) {
  try {
    const { text } = await generateText({
      model: "google/gemini-2.5-flash-image",
      prompt: `Based on this card information:
Title: ${cardTitle}
Description: ${cardDescription}

Generate a concise, detailed image prompt (max 100 characters) for a professional, realistic photograph that visually represents this concept. Focus on HVAC inspection, quality control, or system testing imagery. Return only the prompt text, no additional explanation.`,
    })

    return text.trim()
  } catch (error) {
    console.error("[v0] Error generating image prompt:", error)
    return `${cardTitle} professional scene`
  }
}

export async function generateImageUrl(cardTitle: string, cardDescription: string) {
  try {
    // Create a contextual prompt based on card content
    const prompt = `Professional ${cardTitle.toLowerCase()} scene: ${cardDescription.slice(0, 100)}, HVAC system inspection, high quality black and white photography, monochrome, industrial setting, dramatic lighting`

    const encodedPrompt = encodeURIComponent(prompt)

    // Using pollinations.ai - a free, reliable image generation service
    return `https://image.pollinations.ai/prompt/${encodedPrompt}?width=800&height=600&nologo=true&enhance=true`
  } catch (error) {
    console.error("Error generating image URL:", error)
    return `/placeholder.svg?height=600&width=800&query=${encodeURIComponent(cardTitle)}`
  }
}
