"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

interface VideoSlideProps {
  title?: string
  content?: {
    column1: string[]
    column2: string[]
  }
  onGenerateVideo?: () => Promise<string>
}

export function VideoSlide({
  title = "The Final Inspection",
  content = {
    column1: [
      "A three-step process for quality assurance and system testing to guarantee peak performance.",
      "A three-step process for quality assurance and system testing to guarantee peak performance.",
      "Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.",
    ],
    column2: [
      "A three-step process for quality assurance and system testing to guarantee peak performance.",
      "A three-step process for quality assurance and system testing to guarantee peak performance.",
      "Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.",
    ],
  },
  onGenerateVideo,
}: VideoSlideProps) {
  const [videoUrl, setVideoUrl] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerateVideo = async () => {
    if (!onGenerateVideo) return

    setIsGenerating(true)
    try {
      const url = await onGenerateVideo()
      setVideoUrl(url)
    } catch (error) {
      console.error("Error generating video:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div
      className="w-full aspect-video rounded-lg shadow-2xl p-12 flex flex-col"
      style={{ backgroundColor: "#C7DFE2" }}
    >
      {/* Video Area - Takes up about 40% of slide height */}
      <div className="w-full h-[45%] mb-8 rounded-lg overflow-hidden bg-gray-200/50 flex items-center justify-center">
        {videoUrl ? (
          <video src={videoUrl} controls className="w-full h-full object-cover">
            Your browser does not support the video tag.
          </video>
        ) : (
          <div className="text-center space-y-4">
            <div className="text-gray-600 text-lg">Video Generation Area</div>
            {onGenerateVideo && (
              <Button onClick={handleGenerateVideo} disabled={isGenerating} className="bg-gray-700 hover:bg-gray-800">
                {isGenerating ? "Generating..." : "Generate Video with Veo3"}
              </Button>
            )}
          </div>
        )}
      </div>

      {/* Content Area - Takes up remaining space */}
      <div className="space-y-6">
        <h1 className="text-5xl font-bold text-gray-800">{title}</h1>

        <div className="grid grid-cols-2 gap-8 text-gray-700">
          <div className="space-y-4">
            {content.column1.map((text, index) => (
              <p key={index} className="leading-relaxed">
                {text}
              </p>
            ))}
          </div>

          <div className="space-y-4">
            {content.column2.map((text, index) => (
              <p key={index} className="leading-relaxed">
                {text}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
