"use client"

import { useState, useEffect } from "react"

export default function SlidePage() {
  const [videoUrl, setVideoUrl] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(true)
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState("Initializing...")

  useEffect(() => {
    const generateVideo = async () => {
      try {
        setStatus("Generating video...")
        const response = await fetch("/api/generate-video", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            prompt:
              "A minimalist black and white abstract animation with geometric shapes slowly morphing and transitioning, cinematic, high contrast",
            aspectRatio: "16:9",
          }),
        })

        const data = await response.json()

        if (data.uuid) {
          // Poll for video status
          pollVideoStatus(data.uuid)
        } else if (data.error) {
          setStatus("Failed to generate video")
          setIsGenerating(false)
        }
      } catch (error) {
        console.error("[v0] Error generating video:", error)
        setStatus("Error generating video")
        setIsGenerating(false)
      }
    }

    generateVideo()
  }, [])

  const pollVideoStatus = async (uuid: string) => {
    const maxAttempts = 60 // 5 minutes max
    let attempts = 0

    const checkStatus = async () => {
      try {
        const response = await fetch(`/api/video-status/${uuid}`)
        const data = await response.json()

        setProgress(Math.min((attempts / maxAttempts) * 100, 95))

        if (data.status === "completed" && data.videoUrl) {
          setVideoUrl(data.videoUrl)
          setProgress(100)
          setIsGenerating(false)
          setStatus("Video ready!")
        } else if (data.status === "failed") {
          setStatus("Video generation failed")
          setIsGenerating(false)
        } else if (attempts < maxAttempts) {
          attempts++
          setStatus(data.status === "processing" ? "Processing video..." : "Generating video...")
          setTimeout(checkStatus, 5000) // Check every 5 seconds
        } else {
          setStatus("Timeout: Video generation took too long")
          setIsGenerating(false)
        }
      } catch (error) {
        console.error("[v0] Error checking status:", error)
        setStatus("Error checking video status")
        setIsGenerating(false)
      }
    }

    checkStatus()
  }

  return (
    <main className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#C7DFE2" }}>
      <div className="w-full max-w-7xl animate-fade-in">
        <div
          className="w-full aspect-video rounded-lg shadow-2xl p-12 flex flex-col h-full transition-transform hover:scale-[1.01] duration-300"
          style={{ backgroundColor: "#C7DFE2" }}
        >
          {/* Video Area */}
          <div className="w-full flex-1 mb-8 rounded-lg overflow-hidden bg-gradient-to-br from-gray-900 via-gray-800 to-gray-700 flex items-center justify-center relative animate-slide-down">
            {isGenerating ? (
              <div className="text-center space-y-4 z-10 animate-pulse-slow">
                <div className="w-32 h-32 mx-auto mb-4 border-4 border-white/20 rounded-lg flex items-center justify-center animate-spin-slow">
                  <svg className="w-16 h-16 text-white/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={1.5}
                      d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                    />
                  </svg>
                </div>
                <div className="text-white/80 text-lg font-medium">{status}</div>
                <div className="w-48 h-2 bg-white/10 rounded-full mx-auto overflow-hidden">
                  <div
                    className="h-full bg-white/60 transition-all duration-500 ease-out"
                    style={{ width: `${progress}%` }}
                  />
                </div>
                <div className="text-white/50 text-sm">Using Veo3 API</div>
              </div>
            ) : videoUrl ? (
              <video src={videoUrl} controls autoPlay loop muted className="w-full h-full object-cover animate-fade-in">
                Your browser does not support the video tag.
              </video>
            ) : (
              <div className="text-center space-y-4 z-10">
                <div className="w-32 h-32 mx-auto mb-4 border-4 border-red-500/30 rounded-lg flex items-center justify-center">
                  <svg className="w-16 h-16 text-red-400/60" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </div>
                <div className="text-white/80 text-lg font-medium">{status}</div>
              </div>
            )}
            {/* Decorative elements with animation */}
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="absolute top-4 left-4 w-24 h-24 border border-white rounded-full animate-float" />
              <div className="absolute bottom-4 right-4 w-32 h-32 border border-white rounded-full animate-float-delayed" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 border-2 border-white rounded-lg rotate-45 animate-spin-very-slow" />
            </div>
          </div>

          {/* Content Area */}
          <div className="space-y-6 animate-fade-in-delayed">
            <h1 className="font-bold text-gray-800 text-4xl animate-slide-up">The Final Inspection</h1>

            <div className="grid grid-cols-2 gap-8 text-gray-700">
              <div className="space-y-4 animate-slide-up-delayed-1">
                <p className="leading-relaxed text-base">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
                <p className="leading-relaxed">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
                <p className="leading-relaxed">
                  Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                  detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
                </p>
              </div>

              <div className="space-y-4 animate-slide-up-delayed-2">
                <p className="leading-relaxed">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
                <p className="leading-relaxed">
                  A three-step process for quality assurance and system testing to guarantee peak performance.
                </p>
                <p className="leading-relaxed">
                  Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                  detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
