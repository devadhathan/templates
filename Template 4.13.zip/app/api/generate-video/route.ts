import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { prompt, aspectRatio } = await request.json()

    const response = await fetch("https://veo3o1.com/api/generate-video", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.VEO3_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        generationType: "text_to_video",
        prompt: prompt,
        aspectRatio: aspectRatio || "16:9",
      }),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Veo3 API error:", response.status, errorText)
      return NextResponse.json(
        { error: "Failed to generate video", details: `API error: ${response.status}` },
        { status: 500 },
      )
    }

    const data = await response.json()

    return NextResponse.json({
      uuid: data.uuid,
      status: data.status,
    })
  } catch (error) {
    console.error("[v0] Error generating video:", error)
    return NextResponse.json(
      { error: "Failed to generate video", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
