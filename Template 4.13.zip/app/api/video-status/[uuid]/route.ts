import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest, { params }: { params: Promise<{ uuid: string }> }) {
  try {
    const { uuid } = await params

    const response = await fetch(`https://veo3o1.com/api/video-status/${uuid}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${process.env.VEO3_API_KEY}`,
      },
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error("[v0] Status check error:", response.status, errorText)
      return NextResponse.json(
        { error: "Failed to check video status", details: `API error: ${response.status}` },
        { status: 500 },
      )
    }

    const data = await response.json()

    // Return status and videoUrl when completed
    return NextResponse.json({
      status: data.status,
      videoUrl: data.videoUrl || null,
    })
  } catch (error) {
    console.error("[v0] Error checking video status:", error)
    return NextResponse.json(
      { error: "Failed to check video status", details: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    )
  }
}
