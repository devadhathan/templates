"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"

export default function Slide() {
  const [imageUrl, setImageUrl] = useState<string>("")
  const [isLoading, setIsLoading] = useState(true)
  const [isHovered, setIsHovered] = useState(false)

  useEffect(() => {
    // Fetch contextual image from nano banana API
    const fetchContextualImage = async () => {
      try {
        // Using nano banana API with query for contextual generation
        const query = "professional HVAC system cleaning mountains landscape black and white"
        const response = await fetch(`/api/generate-image?query=${encodeURIComponent(query)}`)
        const data = await response.json()

        if (data.imageUrl) {
          setImageUrl(data.imageUrl)
        }
      } catch (error) {
        console.error("[v0] Error fetching contextual image:", error)
        // Fallback to placeholder
        setImageUrl("/mountain-landscape-black-and-white.jpg")
      } finally {
        setIsLoading(false)
      }
    }

    fetchContextualImage()
  }, [])

  return (
    <div className="relative w-full h-screen flex items-center justify-center bg-gradient-to-br from-gray-200 via-gray-300 to-gray-200 overflow-hidden">
      {/* 16:9 Aspect Ratio Container */}
      <div className="relative w-full max-w-[1920px] aspect-[16/9] bg-gray-200 shadow-2xl rounded-lg overflow-hidden">
        {/* Content Grid */}
        <div className="grid grid-cols-2 gap-12 h-full p-16">
          {/* Left Column - Text Content */}
          <div
            className="flex flex-col space-y-8 animate-fade-in animate-duration-[800ms] justify-start"
            style={{ animationDelay: "200ms" }}
          >
            <h1 className="font-bold text-gray-900 leading-tight animate-fade-in animate-duration-[800ms] text-5xl">
              Welcome to simulation
            </h1>

            <div
              className="space-y-6 text-gray-700 animate-fade-in animate-duration-[800ms]"
              style={{ animationDelay: "400ms" }}
            >
              <p className="font-mono text-sm leading-relaxed">
                A three-step process for quality assurance and system testing to guarantee peak performance.
              </p>

              <p className="font-mono text-sm leading-relaxed">
                Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense,
                detailed breakdown of the essential techniques you'll need for comprehensive system cleaning.
              </p>
            </div>
          </div>

          {/* Right Column - Image */}
          <div
            className="relative flex items-center animate-fade-in animate-duration-[1000ms] justify-start"
            style={{ animationDelay: "600ms" }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
          >
            <div
              className={`
              relative w-full h-[400px] rounded-xl overflow-hidden shadow-2xl
              transition-all duration-700 ease-out
              ${isHovered ? "scale-105 rotate-1" : "scale-100 rotate-0"}
            `}
            >
              {isLoading ? (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-300 animate-pulse">
                  <div className="text-gray-500 font-mono text-sm">Generating contextual image...</div>
                </div>
              ) : (
                <>
                  {/* Blur effect on hover */}
                  <div
                    className={`
                    absolute inset-0 bg-gradient-to-t from-gray-900/30 to-transparent
                    transition-all duration-700
                    ${isHovered ? "opacity-100 backdrop-blur-[2px]" : "opacity-0 backdrop-blur-0"}
                  `}
                  />

                  {/* Image with black and white filter */}
                  <img
                    src={imageUrl || "/placeholder.svg"}
                    alt="Mountain landscape in black and white"
                    className={`
                      w-full h-full object-cover
                      grayscale contrast-110 brightness-100
                      transition-all duration-700
                      ${isHovered ? "scale-110" : "scale-100"}
                    `}
                  />

                  {/* Hover overlay text */}
                  <div
                    className={`
                    absolute inset-0 flex items-center justify-center
                    transition-opacity duration-500
                    ${isHovered ? "opacity-100" : "opacity-0"}
                  `}
                  >
                    <div className="text-white font-mono text-xs px-4 py-2 bg-black/50 rounded-lg backdrop-blur-sm">
                      AI-Generated Contextual Imagery
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Next Button */}
        <div
          className="absolute bottom-16 left-1/2 -translate-x-1/2 animate-fade-in animate-duration-[800ms]"
          style={{ animationDelay: "800ms" }}
        >
          <Button
            size="lg"
            className="bg-black text-white hover:bg-gray-800 px-12 py-6 text-lg font-medium rounded-none transition-all duration-300 hover:scale-105 hover:shadow-2xl group"
          >
            Next
            <span className="inline-block ml-2 transition-transform duration-300 group-hover:translate-x-2">→</span>
          </Button>
        </div>
      </div>

      {/* Subtle background animation */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gray-400/20 rounded-full blur-3xl animate-pulse animate-duration-[3000ms]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-gray-300/20 rounded-full blur-3xl animate-pulse animate-duration-[4000ms]" />
      </div>
    </div>
  )
}
