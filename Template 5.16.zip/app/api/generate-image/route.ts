import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get("query") || "landscape"

    // Nano banana API integration
    // Note: Replace with actual nano banana API endpoint and authentication
    const nanoBananaApiUrl = process.env.NANO_BANANA_API_URL || "https://api.nanobanana.io/v1/generate"
    const apiKey = process.env.NANO_BANANA_API_KEY

    if (!apiKey) {
      console.log("[v0] NANO_BANANA_API_KEY not found, using placeholder")
      // Fallback to placeholder with query
      return NextResponse.json({
        imageUrl: `/placeholder.svg?height=400&width=600&query=${encodeURIComponent(query)}`,
      })
    }

    // Call nano banana API
    const response = await fetch(nanoBananaApiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        prompt: query,
        style: "black-and-white",
        width: 600,
        height: 400,
      }),
    })

    if (!response.ok) {
      throw new Error(`Nano banana API error: ${response.statusText}`)
    }

    const data = await response.json()

    return NextResponse.json({
      imageUrl: data.url || data.imageUrl || `/placeholder.svg?height=400&width=600&query=${encodeURIComponent(query)}`,
    })
  } catch (error) {
    console.error("[v0] Error generating image:", error)

    // Fallback to placeholder
    return NextResponse.json({
      imageUrl: "/mountain-landscape-black-and-white.jpg",
    })
  }
}
