export default function SlidePage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-100 p-4">
      <div
        className="relative w-full max-w-7xl overflow-hidden rounded-lg shadow-2xl"
        style={{ aspectRatio: "16/9", backgroundColor: "#C7DFE2" }}
      >
        <div className="grid h-full grid-cols-1 gap-8 p-12 md:grid-cols-2">
          {/* Left Content */}
          <div className="flex flex-col justify-between">
            <div className="space-y-6">
              <h1 className="font-sans text-5xl font-normal text-gray-800">{"Case study : Topic"}</h1>

              <p className="text-lg leading-relaxed text-gray-700">
                {"A three-step process for quality assurance and system testing to guarantee peak performance."}
              </p>

              <p className="text-lg leading-relaxed text-gray-700">
                {
                  "Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed breakdown of the essential techniques you'll need for comprehensive system cleaning."
                }
              </p>
            </div>

            {/* Ideas Card */}
            <div className="relative w-full max-w-md">
              <div
                className="relative rounded-sm border-2 border-gray-700 bg-yellow-100 p-6 shadow-lg"
                style={{ transform: "rotate(-1deg)" }}
              >
                <div className="flex items-start gap-3">
                  <svg
                    className="h-6 w-6 flex-shrink-0 text-gray-800"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                    />
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                    />
                  </svg>
                  <div>
                    <h2 className="mb-2 font-sans text-xl font-semibold text-gray-800">{"Ideas"}</h2>
                    <p className="text-base leading-relaxed text-gray-700">
                      {"A three-step process for quality assurance and system testing to guarantee peak performance."}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Image */}
          <div className="flex items-center justify-center">
            <div className="h-full w-full overflow-hidden rounded-lg">
              <img
                src="/black-and-white-landscape-mountain-scenery-with-ro.jpg"
                alt="Landscape scenery"
                className="h-full w-full object-cover grayscale"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
