"use client"

import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { Info } from "lucide-react"

export default function ScenarioPage() {
  return (
    <div
      className="relative h-screen w-screen overflow-hidden flex items-center justify-center"
      style={{ backgroundColor: "#C9E4E4" }}
    >
      <div className="relative z-10 w-full max-w-[1920px] aspect-video px-16 flex flex-col py-3">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 text-gray-800 hover:text-gray-900 transition-colors group"
          >
            <div className="rounded-full border border-gray-400 p-2 group-hover:border-gray-600 transition-colors">
              <Info className="h-5 w-5" />
            </div>
            <span className="text-lg font-light">Instructions</span>
          </motion.button>
        </motion.div>

        {/* Center Content */}
        <div className="flex-1 flex flex-col items-center justify-center gap-8">
          {/* Title */}
          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-light text-gray-900 tracking-wide text-5xl"
          >
            {"{{Scenario}}"}
          </motion.h1>

          {/* Profile Image */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
            className="relative w-64 h-64 rounded-lg overflow-hidden shadow-lg"
          >
            <img src="/images/alex-profile.jpg" alt="Alex" className="w-full h-full object-cover" />
          </motion.div>

          {/* Name and Objective */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-center space-y-2"
          >
            <h2 className="text-3xl font-light text-gray-900">Alex</h2>
            <p className="text-lg font-light text-gray-700">{"{{Objective}}"}</p>
          </motion.div>

          {/* Start Call Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Button
              size="lg"
              className="text-xl font-light bg-green-500 hover:bg-green-600 text-white px-16 py-7 rounded-md shadow-lg"
            >
              Start Call
            </Button>
          </motion.div>
        </div>
      </div>
    </div>
  )
}
