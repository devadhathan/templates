"use client"

import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { Info } from "lucide-react"
import { useState } from "react"
import { useRouter } from "next/navigation"

export default function RolePlaySlide() {
  const [isHovered, setIsHovered] = useState(false)
  const router = useRouter()

  return (
    <div
      className="relative h-screen w-screen overflow-hidden flex items-center justify-center"
      style={{ backgroundColor: "#F2CFD1" }}
    >
      <div className="relative z-10 w-full max-w-[1920px] aspect-video px-16 flex flex-col py-3">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="flex items-center justify-between"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2 text-gray-800 hover:text-gray-900 transition-colors group"
          >
            <div className="rounded-full border border-gray-400 p-2 group-hover:border-gray-600 transition-colors">
              <Info className="h-5 w-5" />
            </div>
            <span className="text-lg font-light">Instructions</span>
          </motion.button>
          <motion.h1
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-light text-gray-800 tracking-wide text-base"
          >
            Welcome to Role-play
          </motion.h1>
          <div className="w-40" /> {/* Spacer for center alignment */}
        </motion.div>

        <div className="flex-1 flex flex-col items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.3, ease: "easeOut" }}
            className="relative w-full max-w-5xl aspect-video rounded-2xl overflow-hidden shadow-2xl"
          >
            {/* Black and white placeholder image */}
            <img
              src="/images/design-mode/image.png"
              alt="Role-play scene"
              className="h-full w-full object-cover grayscale"
            />

            {/* Gradient overlay for better text readability */}
            <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/40" />

            {/* Text and button content overlaid on image */}
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-8 p-8">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1, delay: 0.5, ease: "easeOut" }}
                className="text-center space-y-6"
              >
                <motion.h2
                  className="font-light text-white tracking-tight text-balance drop-shadow-lg text-5xl"
                  initial={{ opacity: 0, letterSpacing: "0.2em" }}
                  animate={{ opacity: 1, letterSpacing: "0em" }}
                  transition={{ duration: 1.2, delay: 0.7 }}
                >
                  Are you ready?
                </motion.h2>

                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1, delay: 0.9 }}
                  className="text-white/90 font-light tracking-wide text-lg drop-shadow-md"
                >
                  Your journey starts here
                </motion.p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 1.1, ease: [0.34, 1.56, 0.64, 1] }}
              >
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onHoverStart={() => setIsHovered(true)}
                  onHoverEnd={() => setIsHovered(false)}
                >
                  <Button
                    size="lg"
                    onClick={() => router.push("/scenario")}
                    className="relative text-xl font-light bg-white text-black hover:bg-white/90 overflow-hidden group shadow-xl px-14 py-7 rounded-none"
                  >
                    <motion.span
                      className="relative z-10"
                      animate={{ x: isHovered ? 5 : 0 }}
                      transition={{ duration: 0.3 }}
                    >
                      Start
                    </motion.span>

                    <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-white via-gray-100 to-white"
                      initial={{ x: "-100%" }}
                      animate={{ x: isHovered ? "100%" : "-100%" }}
                      transition={{ duration: 0.6, ease: "easeInOut" }}
                    />
                  </Button>
                </motion.div>
              </motion.div>
            </div>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0.3, scale: 1 }}
          transition={{ duration: 1, delay: 1.2 }}
          className="absolute top-8 left-8 w-20 h-20 border-l-2 border-t-2 border-gray-400"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 0.3, scale: 1 }}
          transition={{ duration: 1, delay: 1.4 }}
          className="absolute bottom-8 right-8 w-20 h-20 border-r-2 border-b-2 border-gray-400"
        />
      </div>
    </div>
  )
}
