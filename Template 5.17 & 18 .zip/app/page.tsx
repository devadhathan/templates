"use client"

import { useState, useEffect } from "react"
import { Info } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function SlidePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string>("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [currentScreen, setCurrentScreen] = useState<"intro" | "scenario">("intro")

  useEffect(() => {
    setIsVisible(true)
    generateImage()
  }, [])

  const generateImage = async () => {
    setIsGenerating(true)
    try {
      const imageUrl = "/person-painting-in-dimly-lit-moody-atmospheric-roo.jpg"
      setGeneratedImage(imageUrl)
    } catch (error) {
      console.error("Error generating image:", error)
      setGeneratedImage("/placeholder.svg?height=600&width=500")
    } finally {
      setIsGenerating(false)
    }
  }

  const handleStart = () => {
    setIsVisible(false)
    setTimeout(() => {
      setCurrentScreen("scenario")
      setIsVisible(true)
    }, 500)
  }

  if (currentScreen === "scenario") {
    return (
      <main className="min-h-screen bg-[#c4c4c4] flex items-center justify-center p-8 overflow-hidden">
        <div className="max-w-6xl w-full">
          {/* Instructions Button */}
          <div
            className={`mb-12 transition-all duration-700 delay-100 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
            }`}
          >
            <button className="flex items-center gap-2 text-foreground/80 hover:text-foreground transition-colors group">
              <div className="w-6 h-6 rounded-full border-2 border-current flex items-center justify-center group-hover:scale-110 transition-transform">
                <Info className="w-4 h-4" />
              </div>
              <span className="font-mono text-sm">Instructions</span>
            </button>
          </div>

          {/* Main Content */}
          <div className="flex flex-col items-center">
            {/* Heading */}
            <div
              className={`text-center mb-16 transition-all duration-1000 delay-300 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
              }`}
            >
              <h1 className="text-foreground mb-4 tracking-tight text-4xl font-medium">Scenario</h1>
            </div>

            {/* Alex Portrait with Name and Objective */}
            <div
              className={`mb-16 transition-all duration-1000 delay-500 ${
                isVisible ? "opacity-100 scale-100" : "opacity-0 scale-90"
              }`}
            >
              <div className="flex flex-col items-center">
                <img src="/professional-headshot-of-a-man-named-alex-with-dar.jpg" alt="Alex" className="w-64 h-64 object-cover mb-6 shadow-lg" />
                <h2 className="text-3xl font-semibold text-foreground mb-2">Alex</h2>
                <p className="text-lg text-foreground/60 font-mono">Objective</p>
              </div>
            </div>

            {/* Start Call Button */}
            <div
              className={`transition-all duration-1000 delay-700 ${
                isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
              }`}
            >
              <Button
                size="lg"
                className="bg-[#2ecc71] text-white hover:bg-[#27ae60] px-16 py-7 text-lg font-medium transition-all duration-300 hover:scale-105 hover:shadow-xl"
              >
                Start Call
              </Button>
            </div>
          </div>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-[#c4c4c4] flex items-center justify-center p-8 overflow-hidden">
      <div className="max-w-6xl w-full">
        {/* Instructions Button */}
        <div
          className={`mb-12 transition-all duration-700 delay-100 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
          }`}
        >
          <button className="flex items-center gap-2 text-foreground/80 hover:text-foreground transition-colors group">
            <div className="w-6 h-6 rounded-full border-current flex items-center justify-center group-hover:scale-110 transition-transform border-0">
              <Info className="w-4 h-4" />
            </div>
            <span className="font-mono text-sm">Instructions</span>
          </button>
        </div>

        {/* Main Content */}
        <div className="flex flex-col items-center h-600 h-16">
          {/* Heading */}
          <div
            className={`text-center mb-16 transition-all duration-1000 delay-300 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <h1 className="font-bold text-foreground mb-4 tracking-tight text-4xl">Are you ready?</h1>
            <p className="text-xl text-foreground/60 font-mono">Your journey starts here</p>
          </div>

          {/* Image with Yellow Background Tile */}
          <div
            className={`relative mb-16 transition-all duration-1000 delay-500 ${
              isVisible ? "opacity-100 scale-100 rotate-0" : "opacity-0 scale-90 rotate-3"
            }`}
          >
            <div
              className="absolute -left-48 -top-1 w-[900px] h-[500px] transform rotate-[-8deg] transition-all duration-700 hover:rotate-[-5deg] hover:scale-105"
              style={{
                animation: isVisible ? "float 6s ease-in-out infinite" : "none",
              }}
            >
              <img
                src="/images/design-mode/image(1).png"
                alt=""
                className="w-full object-cover h-96"
              />
            </div>

            {/* Main Image */}
            <div className="relative z-10 group">
              <div className="overflow-hidden shadow-2xl transition-all duration-500 hover:shadow-3xl hover:scale-[1.02]">
                {isGenerating ? (
                  <div className="w-[500px] h-[400px] bg-gray-300 animate-pulse flex items-center justify-center">
                    <p className="text-gray-500">Generating image...</p>
                  </div>
                ) : (
                  <img
                    src={generatedImage || "/placeholder.svg"}
                    alt="A person painting in a dimly lit room with dramatic lighting"
                    className="w-[500px] object-cover transition-all duration-700 group-hover:brightness-110 h-auto"
                  />
                )}
              </div>
            </div>
          </div>

          {/* Start Button */}
          <div
            className={`transition-all duration-1000 delay-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
            }`}
          >
            <Button
              size="lg"
              onClick={handleStart}
              className="bg-black text-white hover:bg-black/90 px-16 py-7 text-lg font-medium transition-all duration-300 hover:scale-105 hover:shadow-xl"
            >
              Start
            </Button>
          </div>
        </div>
      </div>

      {/* Keyframes for floating animation */}
      <style jsx>{`
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(-8deg);
          }
          50% {
            transform: translateY(-20px) rotate(-5deg);
          }
        }
      `}</style>
    </main>
  )
}
