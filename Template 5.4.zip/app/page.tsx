"use client"

import { useEffect, useState } from "react"

export default function ProfessionalCleaningIntro() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    // Trigger animations after component mounts
    const timer = setTimeout(() => {
      setIsVisible(true)
    }, 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-foreground">
      <div className="w-full max-w-[1920px] aspect-video overflow-hidden rounded-lg shadow-2xl">
        <div className="grid h-full grid-cols-1 md:grid-cols-2">
          {/* Left Section - Yellow with Content */}
          <div
            className={`bg-[#E8FF02] p-8 md:p-12 lg:p-16 flex flex-col transition-all duration-1000 ease-out justify-start ${
              isVisible ? "opacity-100 translate-x-0 blur-0" : "opacity-0 -translate-x-12 blur-sm"
            }`}
          >
            <h1
              className={`text-4xl font-bold text-black mb-6 md:mb-8 transition-all duration-1000 delay-200 ease-out md:text-4xl ${
                isVisible ? "opacity-100 translate-y-0 blur-0" : "opacity-0 translate-y-8 blur-md"
              }`}
            >
              Introduction to the Professional Cleaning Process
            </h1>

            <p
              className={`text-base md:text-lg text-black font-mono leading-relaxed transition-all duration-1000 delay-400 ease-out lg:text-base ${
                isVisible ? "opacity-100 translate-y-0 blur-0" : "opacity-0 translate-y-8 blur-md"
              }`}
            >
              Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
              breakdown of the essential techniques you'll need for comprehensive system cleaning.
            </p>
          </div>

          {/* Right Section - Image Placeholder */}
          <div
            className={`relative bg-gradient-to-br from-sky-400 to-sky-300 transition-all duration-1000 delay-300 ease-out ${
              isVisible ? "opacity-100 translate-x-0 blur-0" : "opacity-0 translate-x-12 blur-sm"
            }`}
          >
            {/* Image placeholder - ready for nano banana API integration */}
            <div className="absolute inset-0 flex items-center justify-center">
              <img
                src="/professional-cleaning-equipment-hvac-system-indust.jpg"
                alt="Professional HVAC cleaning process"
                className="h-full w-full object-cover"
              />
            </div>

            {/* Subtle overlay for depth */}
            <div
              className={`absolute inset-0 bg-black/5 transition-opacity duration-1000 delay-500 ${
                isVisible ? "opacity-100" : "opacity-0"
              }`}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
