"use client"

import { Settings } from "lucide-react"
import { motion } from "framer-motion"
import { useState } from "react"

export default function PresentationSlide() {
  const [hoveredCard, setHoveredCard] = useState<number | null>(null)

  const cards = [
    {
      id: 1,
      title: "Heading 4",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
    },
    {
      id: 2,
      title: "Heading 4",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
    },
    {
      id: 3,
      title: "Heading 4",
      description: "A three-step process for quality assurance and system testing to guarantee peak performance.",
    },
  ]

  return (
    <div className="flex items-center justify-center min-h-screen bg-[#CBCBCB]">
      <main className="w-full max-w-[1920px] aspect-video px-16 py-12 flex flex-col justify-between">
        {/* Header Section */}
        <motion.div
          initial={{ opacity: 0, y: -20, filter: "blur(10px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl"
        >
          <h1 className="font-bold text-[#1a1a1a] mb-6 leading-tight text-4xl">
            Introduction to the Professional Cleaning Process
          </h1>
          <motion.p
            initial={{ opacity: 0, filter: "blur(8px)" }}
            animate={{ opacity: 1, filter: "blur(0px)" }}
            transition={{ duration: 0.8, delay: 0.2, ease: "easeOut" }}
            className="font-mono text-base text-[#3a3a3a] leading-relaxed"
          >
            Welcome to this lesson on the professional HVAC cleaning process. This training provides a dense, detailed
            breakdown of the essential techniques you'll need for comprehensive system cleaning.
          </motion.p>
        </motion.div>

        {/* Cards Section */}
        <div className="grid grid-cols-3 gap-6">
          {cards.map((card, index) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 30, filter: "blur(10px)" }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              transition={{
                duration: 0.6,
                delay: 0.4 + index * 0.15,
                ease: "easeOut",
              }}
              onMouseEnter={() => setHoveredCard(card.id)}
              onMouseLeave={() => setHoveredCard(null)}
              className="relative group"
            >
              <motion.div
                animate={{
                  scale: hoveredCard === card.id ? 1.03 : 1,
                  y: hoveredCard === card.id ? -8 : 0,
                }}
                transition={{ duration: 0.3, ease: "easeOut" }}
                className="h-full p-8 rounded-lg border-2 border-[#9a9a9a] bg-[#b8b8b8]/30 backdrop-blur-sm hover:bg-[#b8b8b8]/50 transition-colors duration-300"
              >
                <div className="mb-6">
                  <Settings className="h-10 text-[#1a1a1a] w-7" />
                </div>
                <h3 className="text-2xl font-semibold text-[#1a1a1a] mb-4">{card.title}</h3>
                <p className="font-mono text-sm text-[#3a3a3a] leading-relaxed">{card.description}</p>

                {/* Hover effect indicator */}
                <motion.div
                  initial={{ width: 0 }}
                  animate={{
                    width: hoveredCard === card.id ? "100%" : 0,
                  }}
                  transition={{ duration: 0.3 }}
                  className="absolute bottom-0 left-0 h-1 bg-[#5a5a5a] rounded-full"
                />
              </motion.div>
            </motion.div>
          ))}
        </div>
      </main>
    </div>
  )
}
