"use client"

import { useEffect, useState } from "react"
import { ClipboardCheck, Wrench, Thermometer, CheckCircle } from "lucide-react"

export default function HVACSlide() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    setIsLoaded(true)
  }, [])

  const cards = [
    { title: "Heading 1", icon: ClipboardCheck, delay: 200 },
    { title: "Heading 2", icon: Wrench, delay: 300 },
    { title: "Heading 3", icon: Thermometer, delay: 400 },
    { title: "Heading 4", icon: CheckCircle, delay: 500 },
  ]

  return (
    <main className="min-h-screen flex items-center justify-center p-8" style={{ backgroundColor: "#E1C7E0" }}>
      {/* 16:9 Container */}
      <div className="w-full max-w-[1920px] aspect-[16/9] flex gap-12 px-16 py-12 flex-col">
        {/* Left Section */}
        <div
          className={`flex-1 flex flex-row justify-between transition-all duration-1000 ${isLoaded ? "opacity-100 translate-x-0" : "opacity-0 -translate-x-12"}`}
        >
          <div>
            <h1 className="font-bold text-gray-900 mb-6 leading-tight text-4xl">The Final Inspection</h1>
            <p className="text-gray-700 leading-relaxed text-base">
              A three-step process for quality assurance and system testing to guarantee peak performance.
            </p>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex-1 flex flex-col justify-between">
          {/* Cards Grid */}
          <div className="grid grid-cols-2 gap-6">
            {cards.map((card, index) => {
              const Icon = card.icon
              return (
                <div
                  key={index}
                  className={`group bg-white/20 backdrop-blur-sm border-2 border-gray-700/40 rounded-2xl p-6 
                  transition-all duration-500 hover:bg-white/30 hover:scale-[1.02] hover:shadow-lg hover:border-gray-900/50
                  cursor-pointer ${isLoaded ? "opacity-100 translate-y-0" : "opacity-0 translate-y-12"}`}
                  style={{ transitionDelay: `${card.delay}ms` }}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <Icon className="w-8 h-8 text-gray-900 transition-transform duration-500 group-hover:rotate-3 group-hover:scale-105" />
                    <h3 className="font-bold text-gray-900 text-lg">{card.title}</h3>
                  </div>
                  <p className="text-base text-gray-700 leading-relaxed">
                    A three-step process for quality assurance and system testing to guarantee peak performance.
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </main>
  )
}
